package sunflower.customer.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import sunflower.customer.entity.Customer;
import sunflower.customer.entity.CustomerListHelp;
import sunflower.customer.entity.HistoryRecord;
import sunflower.user.entity.User;
import sunflower.util.support.HibernateUtil;

public class HistoryRecordDao {
	private Session session;

	// 获取历史交易记录 by id
	public HistoryRecord getHistoryRecord(String historyRecordID) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		HistoryRecord historyRecord = (HistoryRecord) session.get(
				HistoryRecord.class, historyRecordID);
		return historyRecord;
	}

	// 获取客户的历史交易记录 按时间排序
	public List<HistoryRecord> getCustomerHistoryRecords(Customer customer) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		List<HistoryRecord> resords = (List<HistoryRecord>) session
				.createCriteria(HistoryRecord.class)
				.add(Restrictions.eq("customer", customer)).list();
		return resords;
	}
	
	//Yangdi-2014-7-23
	//通过制定查询语句得到客户列表
	public int getHistoryListCount(String hql, String customerId){
		session = HibernateUtil.getSessionFactory().getCurrentSession();		
		List<HistoryRecord> list = null;
		Transaction tx = null;
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter(0, customerId);
			list = query.list();
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		return list.size();
	}
	
	public List<HistoryRecord> getHistoryRecordByCutomerId(String customerId){
		//System.out.println("-->	HistoryDao: 进入getHistoryRecordByCutomerId");
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		List<HistoryRecord> list = null;
		Transaction tx = null;
		System.out.println("--> HistoryRecordDao: customId="+customerId);
		
		String hql="from HistoryRecord where customer_id=?";
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter(0, customerId);
			list = query.list();
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		return list;
	}

	//Yangdi-2014-07-21
	//分页：从数据库得出分页数据
	public List<HistoryRecord> queryByPage(String hql, int offset, int pageSize, String customerId){
		session = HibernateUtil.getSessionFactory().getCurrentSession();		
		List<HistoryRecord> list = null;
		Transaction tx = null;
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql).setFirstResult(offset).setMaxResults(pageSize);
			query.setParameter(0, customerId);
			list = query.list();
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		return list;
	}
	
	public HistoryRecord getHistoryRecordById(String historyRecordId){
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		List<HistoryRecord> list = null;
		Transaction tx = null;
		
		String hql="from HistoryRecord where history_record_id=?";
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter(0, historyRecordId);
			list = query.list();
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		return list.get(0);
	}
	
}
