package sunflower.customer.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import sunflower.customer.entity.HistoryRecord;
import sunflower.customer.entity.RecordItem;
import sunflower.util.support.HibernateUtil;

public class RecordItemDao {
	private Session session;
	
	//Yangdi-2014-7-24
	public HistoryRecord getHistoryRecordById(String historyRecordId){
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		List<HistoryRecord> list = null;
		Transaction tx = null;
		
		String hql="from HistoryRecord where history_record_id=?";
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter(0, historyRecordId);
			list = query.list();
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		return list.get(0);
	}

	
	//Yangdi-2014-7-23
	//通过制定查询语句得到客户列表
	public int getRecordItemCount(String hql, String historyRecordId){
		session = HibernateUtil.getSessionFactory().getCurrentSession();		
		List<RecordItem> list = null;
		Transaction tx = null;
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter(0, historyRecordId);
			list = query.list();
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		return list.size();
	}

	//Yangdi-2014-07-21
	//分页：从数据库得出分页数据
	public List<RecordItem> queryByPage(String hql, int offset, int pageSize, String historyRecordId){
		session = HibernateUtil.getSessionFactory().getCurrentSession();		
		List<RecordItem> list = null;
		//List<User> userList = null;		
		Transaction tx = null;
		
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql).setFirstResult(offset).setMaxResults(pageSize);
			query.setParameter(0, historyRecordId);
			list = query.list();
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		return list;
	}
		
}
