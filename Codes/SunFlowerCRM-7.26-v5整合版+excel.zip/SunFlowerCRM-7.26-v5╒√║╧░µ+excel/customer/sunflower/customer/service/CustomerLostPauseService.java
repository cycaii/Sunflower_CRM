package sunflower.customer.service;

import java.util.List;

import sunflower.customer.entity.CustomerLostPause;


public interface CustomerLostPauseService {
	
	//Yangdi-2014-7-25-11:40pm
	public boolean saveCustomerLostPause(CustomerLostPause customerLostPause);
	
	//Yangdi-2014-7-25-10:21pm
	public CustomerLostPause getCustomerLostPauseByCustomerId(String customerId);
	
	public boolean addCustomerLostPause(CustomerLostPause customerLostPause);

	public boolean updateCustomerLostPause(CustomerLostPause customerLostPause);

	public List<CustomerLostPause> getAllCustomerLostPauses();

}
