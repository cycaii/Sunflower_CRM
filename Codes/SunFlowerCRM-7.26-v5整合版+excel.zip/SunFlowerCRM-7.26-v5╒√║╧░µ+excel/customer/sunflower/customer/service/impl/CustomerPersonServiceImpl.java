package sunflower.customer.service.impl;

import java.util.List;

import sunflower.customer.dao.CustomerPersonDao;
import sunflower.customer.entity.CustomerPerson;
import sunflower.customer.entity.HistoryRecord;
import sunflower.customer.entity.PageBean;
import sunflower.customer.service.CustomerPersonService;

public class CustomerPersonServiceImpl implements CustomerPersonService {
	CustomerPersonDao cpd = new CustomerPersonDao();
	
	//Yangdi-2104-7-25
	@Override
	public boolean deleteCustomerPerosonById(String customerPersonId){
		return cpd.deleteCustomerPersonById(customerPersonId);
	}
	
	
	//Yangdi-2104-7-25
	@Override
	public boolean saveEdit(CustomerPerson customerPerson){
		System.out.println("--> 修改：客户名称="+customerPerson.getCustomerPersonName());
		CustomerPerson cp = cpd.getCustomerPerson(customerPerson.getCustomerPersonId());
		cp.setCustomerPersonName(customerPerson.getCustomerPersonName());
		cp.setCustomerPersonMemo(customerPerson.getCustomerPersonMemo());
		cp.setCustomerPersonMobile(customerPerson.getCustomerPersonMobile());
		cp.setCustomerPersonPosition(customerPerson.getCustomerPersonPosition());
		cp.setCustomerPersonSex(customerPerson.getCustomerPersonSex());
		cp.setCustomerPersonTel(customerPerson.getCustomerPersonTel());
		
		return cpd.updateCustomerPerson(cp);
	}
	
	//Yangdi-2014-7-21
	//分页：提供相应的查询语句，每一页显示的记录数据，当前页码，来得到相应的显示以及查询列表
	@Override
	public PageBean getPageBean(int pageSize, int page, String hql, String sortFlag, String searchCusKey, String customerId, String customerName)
    {
        PageBean pageBean = new PageBean();
        
        //得到查询得到的记录的数目
        String currentSortFlag = pageBean.getsf(sortFlag);
        String currentSearchKey = pageBean.getsk(searchCusKey);
        if(currentSortFlag!=null || currentSortFlag=="")
        	hql=hql + currentSortFlag;
        
        int allRows = cpd.getCustomerPersonCount(hql, customerId);
        //得到总页数
        int totalPage = pageBean.getTotalPages(pageSize, allRows);
        //达到当前显示页面
        int currentPage = pageBean.getCurPage(page);
        //得到当前页面在数据库查记录中的位置
        int offset = pageBean.getCurrentPageOffset(pageSize, currentPage);
        //得到查询后客户列表
        List<CustomerPerson> list = cpd.queryByPage(hql, offset, pageSize, customerId);
        
        pageBean.setCustomerPersonList(list);

        pageBean.setAllRows(allRows);
        pageBean.setCurrentPage(currentPage);
        pageBean.setTotalPage(totalPage);
        pageBean.setSortFlag(currentSortFlag);
        pageBean.setSearchCusKey(currentSearchKey);
        pageBean.setCustomerId(customerId);
        pageBean.setCustomerName(customerName);
        
        return pageBean;
    }


	@Override
	public CustomerPerson getCustomerPersonById(String customerPersonID) {
		return cpd.getCustomerPerson(customerPersonID);
	}

	@Override
	public boolean addCustomerPerson(CustomerPerson customerPerson) {
		return cpd.saveCustomerPerson(customerPerson);
	}

	@Override
	public boolean updateCustomerPerson(CustomerPerson customerPerson) {
		return cpd.updateCustomerPerson(customerPerson);
	}

	@Override
	public boolean deleteCustomerPerson(CustomerPerson customerPerson) {
		return cpd.deleteCustomerPerson(customerPerson);
	}

}
