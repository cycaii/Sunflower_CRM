package sunflower.statistical.action;

import java.util.ArrayList;
import sunflower.customer.entity.Customer;
import sunflower.statistical.entity.cusCtriAnalyze;
import sunflower.statistical.service.statisticService;
import sunflower.statistical.service.impl.statisticServiceImpl;

import com.opensymphony.xwork2.ActionSupport;
public class statisticsAction extends ActionSupport{
    private ArrayList<Customer> customers  = new ArrayList<Customer>(); 
    private ArrayList<cusCtriAnalyze> cus = new ArrayList<cusCtriAnalyze>();
	statisticService service = new statisticServiceImpl();
	private static final long serialVersionUID = 1L;
	public String cusCtributeAnalyze(){
		customers = service.getCustomers();
		for(int i = 0;i<customers.size();i++){
			cusCtriAnalyze ele = new cusCtriAnalyze();
			ele.setCusName(customers.get(i).getCustomerName());
			cus.add(ele);
		} 
		for(int j = 0;j<customers.size();j++){
			double sum = 0;
			for(int k = 0;k<customers.get(j).getHistoryRecords().size();k++){
				for(int l = 0;l<customers.get(j).getHistoryRecords().get(k).getRecordItems().size();l++){
					sum = sum + customers.get(j).getHistoryRecords().get(k).getRecordItems().get(l).getRecordItemTotalPrice();
				}
			}
			cus.get(j).setTotal_price(sum);
		}
		return "cusCtributeAnalyze";
	}
	public ArrayList<Customer> getCustomers() {
		return customers;
	}
	public void setCustomers(ArrayList<Customer> customers) {
		this.customers = customers;
	}
	public ArrayList<cusCtriAnalyze> getCus() {
		return cus;
	}
	public void setCus(ArrayList<cusCtriAnalyze> cus) {
		this.cus = cus;
	}
	
	
}
