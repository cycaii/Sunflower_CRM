package sunflower.statistical.action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import sunflower.statistical.entity.BusinessAnalyze;
import sunflower.statistical.entity.ComponentAnalyze;
import sunflower.statistical.entity.LostAnalyze;
import sunflower.statistical.service.StatisticalService;
import sunflower.statistical.service.impl.StatisticalServiceImpl;

import com.opensymphony.xwork2.ActionSupport;

public class StatisticalAction extends ActionSupport {
	
	private StatisticalService statisticalService;
	
	//businessAnalyze.jsp
	private List<BusinessAnalyze> businessAnalyze_list;
	private int businessAnalyze_record_size;
	//lostAnalyze.jsp用的
	private List<LostAnalyze> lostAnalyze_list;
	private int lostAnalyze_record_size;
	//componentAnalyze.jsp
	private List<ComponentAnalyze> componentAnalyze_list;
	private int componentAnalyze_record_size;
	//分页，排序用的
	private String order_parameter = null;
	private int total_page_number;
	private int current_page;
	private int record_per_page;
	public StatisticalAction()
	{
	}
	//lostAnalyze.jsp
	public String lostAnalyze()
	{

		//查看用的参数
		String view_parameter = null;
		

		//查看参数信息
		if ( ServletActionContext.getRequest().getParameter("view") != null )
			view_parameter = ServletActionContext.getRequest().getParameter("view");
		//排序参数信息
		if ( ServletActionContext.getRequest().getParameter("order") != null )
			order_parameter = ServletActionContext.getRequest().getParameter("order");
		
		
		if ( statisticalService == null )
			statisticalService = new StatisticalServiceImpl();
		if ( view_parameter == null )
		{
			//分页显示
			//单页记录数，改这个就改了每页显示的记录数，目前为5
			record_per_page = 10;
			//获取分页信息
			if ( ServletActionContext.getRequest().getParameter("page") != null )
				current_page = Integer.parseInt(ServletActionContext.getRequest().getParameter("page"));
			else
				current_page = 1;

			//这里进行排序
			order_parameter = ServletActionContext.getRequest().getParameter("order");
			if ( order_parameter != null ) //要求排序
			{
				//按照客户名称排序
				if ( order_parameter.equals("customer_name") )
				{
					lostAnalyze_list = statisticalService.getLostAnalyzeListByPage_customerNameOrder(current_page, record_per_page);
				}
				else
				{
					//按照客户经理名称排序
					if ( order_parameter.equals("user_name") )
					{
						lostAnalyze_list = statisticalService.getLostAnalyzeListByPage_userNameOrder(current_page, record_per_page);
					}
				}
			}
			else
			{
				//无需排序
				lostAnalyze_list = statisticalService.getLostAnalyzeListByPage(current_page, record_per_page);
			}
			
			lostAnalyze_record_size = statisticalService.getLostAnalyzeList().size();
			//获取当前页记录 
			total_page_number = lostAnalyze_record_size / record_per_page;
			System.out.println("Total_page_number:" + total_page_number );
			System.out.println("lostAnalyze_record_size:" + lostAnalyze_record_size);
			System.out.println("record_per_page:" + record_per_page);
		}
		else
		{
			//无需分页
			if ( view_parameter.equals("all") )
			{
				//显示全部，这里排序或是全部
				order_parameter = ServletActionContext.getRequest().getParameter("order");
				if ( order_parameter != null ) //要求排序
				{
					//按照客户名称排序
					if ( order_parameter.equals("customer_name") )
					{
						lostAnalyze_list = statisticalService.getLostAnalyzeListByPage_customerNameOrder(1,  statisticalService.getLostAnalyzeList().size());
					}
					else
					{
						//按照客户经理名称排序
						if ( order_parameter.equals("user_name") )
						{
							lostAnalyze_list = statisticalService.getLostAnalyzeListByPage_userNameOrder(1,  statisticalService.getLostAnalyzeList().size());
						}
					}
				}
				else
				{
					//无需排序
					lostAnalyze_list = statisticalService.getLostAnalyzeList();
				}
				current_page = 1;
				record_per_page = lostAnalyze_list.size();
				total_page_number = 1;
				lostAnalyze_record_size = lostAnalyze_list.size();
			}
		}
		return "lostAnalyze";
	}
	//businessAnalyze.jsp
	public String businessAnalyze()
	{

		//查看用的参数
		String view_parameter = null;
		

		//查看参数信息
		if ( ServletActionContext.getRequest().getParameter("view") != null )
			view_parameter = ServletActionContext.getRequest().getParameter("view");
		//排序参数信息
		if ( ServletActionContext.getRequest().getParameter("order") != null )
			order_parameter = ServletActionContext.getRequest().getParameter("order");
		
		
		if ( statisticalService == null )
			statisticalService = new StatisticalServiceImpl();
		if ( view_parameter == null )
		{
			//分页显示
			//单页记录数，改这个就改了每页显示的记录数，目前为5
			record_per_page = 10;
			//获取分页信息
			if ( ServletActionContext.getRequest().getParameter("page") != null )
				current_page = Integer.parseInt(ServletActionContext.getRequest().getParameter("page"));
			else
				current_page = 1;

			//这里进行排序
			order_parameter = ServletActionContext.getRequest().getParameter("order");
			if ( order_parameter != null ) //要求排序
			{
				//按照客户名称排序
				if ( order_parameter.equals("business_count") )
				{
					businessAnalyze_list = statisticalService.getBusinessAnalyzeListByPage_businessNumberOrder(current_page, record_per_page);
				}
				else
				{
					//按照客户经理名称排序
					if ( order_parameter.equals("business_type") )
					{
						businessAnalyze_list = statisticalService.getBusinessAnalyzeListByPage_businessTypeOrder(current_page,  record_per_page );
					}
				}
			}
			else
			{
				//无需排序
				businessAnalyze_list = statisticalService.getBusinessAnalyzeListByPage(current_page, record_per_page);
			}
			
			businessAnalyze_record_size = statisticalService.getBusinessAnalyzeList().size();
			//获取当前页记录 
			total_page_number = businessAnalyze_record_size / record_per_page;
			System.out.println("Total_page_number:" + total_page_number );
			System.out.println("lostAnalyze_record_size:" + businessAnalyze_record_size);
			System.out.println("record_per_page:" + record_per_page);
		}
		else
		{
			//无需分页
			if ( view_parameter.equals("all") )
			{
				//显示全部，这里排序或是全部
				order_parameter = ServletActionContext.getRequest().getParameter("order");
				if ( order_parameter != null ) //要求排序
				{
					if ( order_parameter.equals("business_count") )
					{
						businessAnalyze_list = statisticalService.getBusinessAnalyzeListByPage_businessNumberOrder(current_page, statisticalService.getBusinessAnalyzeList().size() );
					}
					else
					{
						//按照客户经理名称排序
						if ( order_parameter.equals("business_type") )
						{
							businessAnalyze_list = statisticalService.getBusinessAnalyzeListByPage_businessTypeOrder(current_page,  statisticalService.getBusinessAnalyzeList().size() );
						}
					}
				}
				else
				{
					//无需排序
					businessAnalyze_list = statisticalService.getBusinessAnalyzeList();
				}
				current_page = 1;
				record_per_page = businessAnalyze_list.size();
				total_page_number = 1;
				businessAnalyze_record_size = businessAnalyze_list.size();
			}
		}
		return "businessAnalyze";
	}
	//componentAnalyze.jsp
	public String componentAnalyze()
	{
		//查看用的参数
				String view_parameter = null;
				

				//查看参数信息
				if ( ServletActionContext.getRequest().getParameter("view") != null )
					view_parameter = ServletActionContext.getRequest().getParameter("view");
				//排序参数信息
				if ( ServletActionContext.getRequest().getParameter("order") != null )
					order_parameter = ServletActionContext.getRequest().getParameter("order");
				
				
				if ( statisticalService == null )
					statisticalService = new StatisticalServiceImpl();
				if ( view_parameter == null )
				{
					//分页显示
					//单页记录数，改这个就改了每页显示的记录数，目前为5
					record_per_page = 10;
					//获取分页信息
					if ( ServletActionContext.getRequest().getParameter("page") != null )
						current_page = Integer.parseInt(ServletActionContext.getRequest().getParameter("page"));
					else
						current_page = 1;

					//这里进行排序
					order_parameter = ServletActionContext.getRequest().getParameter("order");
					if ( order_parameter != null ) //要求排序
					{
						//按照客户名称排序
						if ( order_parameter.equals("customer_count") )
						{
							componentAnalyze_list = statisticalService.getComponentAnalyzeListByPage_customerNumberOrder(current_page, record_per_page);
						}
						else
						{
							//按照客户经理名称排序
							if ( order_parameter.equals("customer_level") )
							{
								componentAnalyze_list = statisticalService.getComponentAnalyzeListByPage_customerLevelOrder(current_page,  record_per_page );
							}
						}
					}
					else
					{
						//无需排序
						componentAnalyze_list = statisticalService.getComponentAnalyzeListByPage(current_page, record_per_page);
					}
					
					componentAnalyze_record_size = statisticalService.getComponentAnalyzeList().size();
					//获取当前页记录 
					total_page_number = componentAnalyze_record_size / record_per_page;
					System.out.println("Total_page_number:" + total_page_number );
					System.out.println("lostAnalyze_record_size:" + componentAnalyze_record_size);
					System.out.println("record_per_page:" + record_per_page);
				}
				else
				{
					//无需分页
					if ( view_parameter.equals("all") )
					{
						//显示全部，这里排序或是全部
						order_parameter = ServletActionContext.getRequest().getParameter("order");
						if ( order_parameter != null ) //要求排序
						{
							//按照客户名称排序
							if ( order_parameter.equals("customer_count") )
							{
								componentAnalyze_list = statisticalService.getComponentAnalyzeListByPage_customerNumberOrder(current_page, statisticalService.getComponentAnalyzeList().size());
							}
							else
							{
								//按照客户经理名称排序
								if ( order_parameter.equals("customer_level") )
								{
									componentAnalyze_list = statisticalService.getComponentAnalyzeListByPage_customerLevelOrder(current_page, statisticalService.getComponentAnalyzeList().size() );
								}
							}
						}
						else
						{
							//无需排序
							componentAnalyze_list = statisticalService.getComponentAnalyzeList();
						}
						current_page = 1;
						record_per_page = componentAnalyze_list.size();
						total_page_number = 1;
						componentAnalyze_record_size = componentAnalyze_list.size();
					}
				}		
		return "componentAnalyze";
	}
	
	
	
	public List<LostAnalyze> getLostAnalyze_list() {
		return lostAnalyze_list;
	}
	public void setLostAnalyze_list(ArrayList<LostAnalyze> lostAnalyze_list) {
		this.lostAnalyze_list = lostAnalyze_list;
	}

	public int getLostAnalyze_record_size() {
		return lostAnalyze_record_size;
	}
	public int getRecord_per_page()
	{
		return this.record_per_page;
	}
	public void setRecord_per_page(int record_per_page)
	{
		this.record_per_page = record_per_page;
	}
	public int getCurrent_page()
	{
		return this.current_page;
	}
	public void setCurrent_page(int current_page)
	{
		this.current_page = current_page;
	}
	public void setLostAnalyze_record_size(int lostAnalyze_record_size) {
		this.lostAnalyze_record_size = lostAnalyze_record_size;
	}

	
	public int getTotal_page_number() {
		return total_page_number;
	}

	public void setTotal_page_number(int total_page_number) {
		this.total_page_number = total_page_number;
	}
	
	public String getOrder_parameter() {
		return order_parameter;
	}

	public void setOrder_parameter(String order_parameter) {
		this.order_parameter = order_parameter;
	}
	public int getBusinessAnalyze_record_size() {
		return businessAnalyze_record_size;
	}
	public void setBusinessAnalyze_record_size(int businessAnalyze_record_size) {
		this.businessAnalyze_record_size = businessAnalyze_record_size;
	}
	public List<BusinessAnalyze> getBusinessAnalyze_list() {
		return businessAnalyze_list;
	}
	public void setBusinessAnalyze_list(List<BusinessAnalyze> businessAnalyze_list) {
		this.businessAnalyze_list = businessAnalyze_list;
	}
	public List<ComponentAnalyze> getComponentAnalyze_list() {
		return componentAnalyze_list;
	}
	public void setComponentAnalyze_list(List<ComponentAnalyze> componentAnalyze_list) {
		this.componentAnalyze_list = componentAnalyze_list;
	}
	public int getComponentAnalyze_record_size() {
		return componentAnalyze_record_size;
	}
	public void setComponentAnalyze_record_size(int componentAnalyze_record_size) {
		this.componentAnalyze_record_size = componentAnalyze_record_size;
	}
}
