package sunflower.statistical.service.impl;

import java.util.ArrayList;
import java.util.List;

import sunflower.statistical.dao.cusCtributeAnalyzeDao;
import sunflower.customer.entity.Customer;
import sunflower.statistical.service.statisticService;

public class statisticServiceImpl implements statisticService{
	cusCtributeAnalyzeDao dao = new cusCtributeAnalyzeDao();
	public ArrayList<Customer> getCustomers() {
		return dao.getAllCustomer();
	}
	public Customer getCustomerByName(String customerName){
		return dao.getCustomerByName(customerName);
	}
}
