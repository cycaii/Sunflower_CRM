package sunflower.statistical.entity;

import java.io.Serializable;

public class ComponentAnalyzeId implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String customer_id;
	private String customer_level;
	private int customer_count;
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_level() {
		return customer_level;
	}
	public void setCustomer_level(String customer_level) {
		this.customer_level = customer_level;
	}
	public int getCustomer_count() {
		return customer_count;
	}
	public void setCustomer_count(int customer_count) {
		this.customer_count = customer_count;
	}
}
