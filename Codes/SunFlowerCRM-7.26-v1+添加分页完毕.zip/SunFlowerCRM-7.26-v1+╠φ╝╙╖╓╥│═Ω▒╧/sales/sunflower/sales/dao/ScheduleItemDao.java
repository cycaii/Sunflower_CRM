package sunflower.sales.dao;

import org.hibernate.Session;

import sunflower.sales.entity.ScheduleItem;
import sunflower.util.support.HibernateUtil;
import sunflower.util.support.UUIDGenerator;

public class ScheduleItemDao {
	private Session session;

	// 添加ScheduleItem
	public boolean saveScheduleItem(ScheduleItem scheduleItem) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		try {
			String uuid = UUIDGenerator.getUUID();
			scheduleItem.setScheduleId(uuid);
			session.save(scheduleItem);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// 修改ScheduleItem
	public boolean updateScheduleItem(ScheduleItem scheduleItem) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		try {
			System.out.println("ScheduleItemDao----update:"
					+ scheduleItem.getScheduleId() + "   "
					+ scheduleItem.getScheduleContent() + "  "
					+ scheduleItem.getScheduleMemo());
			session.update(scheduleItem);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// 删除计划项
	public boolean deleteScheduleItem(ScheduleItem scheduleItem) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		try {
			session.delete(session.load(ScheduleItem.class,
					scheduleItem.getScheduleId()));
			session.getTransaction().commit();
		} catch (Exception e) {
			return false;
		}

		return true;
	}

	// 获取scheduleItem
	public ScheduleItem getScheduleItem(String scheduleItemid) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		ScheduleItem scheduleItem = (ScheduleItem) session.get(
				ScheduleItem.class, scheduleItemid);
		return scheduleItem;
	}

}
