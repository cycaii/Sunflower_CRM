package sunflower.customer.service.impl;

import java.util.List;

import sunflower.customer.dao.HistoryRecordDao;
import sunflower.customer.entity.Customer;
import sunflower.customer.entity.HistoryRecord;
import sunflower.customer.entity.PageBean;
import sunflower.customer.service.HistoryRecordService;

public class HistoryRecordServiceImpl implements HistoryRecordService {
	HistoryRecordDao hrd = new HistoryRecordDao();
	
	//Yangdi-2014-7-21
	//分页：提供相应的查询语句，每一页显示的记录数据，当前页码，来得到相应的显示以及查询列表
	@Override
	public PageBean getPageBean(int pageSize, int page, String hql, String sortFlag, String searchCusKey, String customerId, String customerName)
    {
        PageBean pageBean = new PageBean();
        
        //得到查询得到的记录的数目
        String currentSortFlag = pageBean.getsf(sortFlag);
        String currentSearchKey = pageBean.getsk(searchCusKey);
        if(currentSortFlag!=null || currentSortFlag=="")
        	hql=hql + currentSortFlag;
        
        int allRows = hrd.getHistoryListCount(hql, customerId);
        //得到总页数
        int totalPage = pageBean.getTotalPages(pageSize, allRows);
        //达到当前显示页面
        int currentPage = pageBean.getCurPage(page);
        //得到当前页面在数据库查记录中的位置
        int offset = pageBean.getCurrentPageOffset(pageSize, currentPage);
        //得到查询后客户列表
        List<HistoryRecord> list = hrd.queryByPage(hql, offset, pageSize, customerId);//personDAO.queryByPage(hql, offset, pageSize);

        pageBean.setHistoryList(list);//.setList(list);

        pageBean.setAllRows(allRows);
        pageBean.setCurrentPage(currentPage);
        pageBean.setTotalPage(totalPage);
        pageBean.setSortFlag(currentSortFlag);
        pageBean.setSearchCusKey(currentSearchKey);
        pageBean.setCustomerId(customerId);
        pageBean.setCustomerName(customerName);
        
        return pageBean;
    }

	
	@Override
	public List<HistoryRecord> getHistoryRecordByCustomerId(String customerId){
		return hrd.getHistoryRecordByCutomerId(customerId);
	}
	
	@Override
	public HistoryRecord getHistoryRecord(String historyRecordID) {
		return hrd.getHistoryRecord(historyRecordID);
	}

	@Override
	public List<HistoryRecord> getCustomerHistoryRecords(Customer customer) {
		return hrd.getCustomerHistoryRecords(customer);
	}

}
