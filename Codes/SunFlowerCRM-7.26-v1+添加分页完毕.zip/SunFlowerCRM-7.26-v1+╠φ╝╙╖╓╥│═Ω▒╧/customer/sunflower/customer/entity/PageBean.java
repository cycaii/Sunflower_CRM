package sunflower.customer.entity;

import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


//Yangdi-2014-07-21
public class PageBean {
	private List<Customer> list; //通过hql从数据库分页查询出来的list集合
	private List<HistoryRecord> latestRecordList;
	private List<CustomerListHelp> cutomerList;
	private Map mapHistoCusto = new LinkedHashMap();//这个map是有序的，按照put的顺序输出
	private String sortFlag;//保存查询条件
	private String searchCusKey;//保存查询关键字
	private List<HistoryRecord> historyList;
	
	//为了historyList.jsp中的js能得到值
	private String customerId;
	private String customerName;
	
	public String getSearchCusKey() {
		return searchCusKey;
	}

	public void setSearchCusKey(String searchCusKey) {
		this.searchCusKey = searchCusKey;
	}

	public String getSortFlag() {
		return sortFlag;
	}

	public void setSortFlag(String sortFlag) {
		this.sortFlag = sortFlag;
	}

	public Map getMapHistoCusto() {
		return mapHistoCusto;
	}

	public void setMapHistoCusto(Map mapHistoCusto) {
		this.mapHistoCusto = mapHistoCusto;
	}

	public Map setMap2(List<Customer> customers, List<HistoryRecord> historyRecords){
		for(int i = 0; i < customers.size(); i++){
			if(historyRecords.get(i) != null)
				mapHistoCusto.put(customers.get(i), historyRecords.get(i).getHistoryRecordDate());
			else
				mapHistoCusto.put(customers.get(i), null);
		}		//test
		
		
		return mapHistoCusto; 
	}
	
	public Map setMap(List<Customer> customers, List<HistoryRecord> historyRecords){
		
		for(int i = 0; i < customers.size(); i++){
			mapHistoCusto.put(customers.get(i),historyRecords.get(i));
		}
		//this.setMaphistoCusto(mapHistoCusto);
		
		return mapHistoCusto;
	}
    

	public List<HistoryRecord> getLatestRecordList() {
		return latestRecordList;
	}

	public void setLatestRecordList(List<HistoryRecord> latestRecordList) {
		this.latestRecordList = latestRecordList;
	}

	private int allRows; //总记录数
    
    private int totalPage; //总页数
    
    private int currentPage; //当前页

    public List<Customer> getList()
    {
        return list;
    }

    public void setList(List<Customer> list)
    {
        this.list = list;
    }

    public int getAllRows()
    {
        return allRows;
    }

    public void setAllRows(int allRows)
    {
        this.allRows = allRows;
    }

    public int getTotalPage()
    {
        return totalPage;
    }

    public void setTotalPage(int totalPage)
    {
        this.totalPage = totalPage;
    }

    public int getCurrentPage()
    {
        return currentPage;
    }

    public void setCurrentPage(int currentPage)
    {
        this.currentPage = currentPage;
    }
    
    /**
     * 得到总页数
     * @param pageSize 每页记录数
     * @param allRows  总记录数
     * @return 总页数
     */
    public int getTotalPages(int pageSize, int allRows)
    {
        int totalPage = (allRows % pageSize == 0)? (allRows / pageSize): (allRows / pageSize) + 1;
        
        return totalPage;
    }
    
    /**
     * 得到当前开始记录号
     * @param pageSize 每页记录数
     * @param currentPage 当前页
     * @return
     */
    public int getCurrentPageOffset(int pageSize, int currentPage)
    {
        int offset = pageSize * (currentPage - 1);
        
        return offset;
    }
    
    /**
     * 得到当前页， 如果为0 则开始第一页，否则为当前页
     * @param page
     * @return
     */
    public int getCurPage(int page)
    {
        int currentPage = (page == 0)? 1: page;
        
        return currentPage;
    }
    public String getsf(String sf)
    {
        String sortFlag = (sf == null)? "": sf;
        
        return sortFlag;
    }
    public String getsk(String sk)
    {
        String searchKey = (sk == null)? "": sk;
        
        return searchKey;
    }

	public List<CustomerListHelp> getCutomerList() {
		return cutomerList;
	}

	public void setCutomerList(List<CustomerListHelp> cutomerList) {
		this.cutomerList = cutomerList;
	}

	public List<HistoryRecord> getHistoryList() {
		return historyList;
	}

	public void setHistoryList(List<HistoryRecord> historyList) {
		this.historyList = historyList;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
    
    
}
