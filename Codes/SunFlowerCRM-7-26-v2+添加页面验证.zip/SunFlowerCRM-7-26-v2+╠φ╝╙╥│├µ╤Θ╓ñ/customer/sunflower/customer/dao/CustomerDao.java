package sunflower.customer.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;













import sunflower.customer.entity.Customer;
import sunflower.customer.entity.CustomerListHelp;
import sunflower.customer.entity.HistoryRecord;
import sunflower.user.entity.User;
import sunflower.util.support.HibernateUtil;

public class CustomerDao {
	private Session session;
	
	//Yangdi-2014-7-21-废弃方法
	public List<Customer> getTheCustomerListShowInfo(List<Customer> list){
		
		HistoryRecord latest;
		
		for(int i = 0; i < list.size(); i++){
			//List<HistoryRecord> historyRecords;
			//historyRecords = list.get(i).getHistoryRecords();
			//slatest = list.get(i).getHistoryRecords();
			//for(int j = 0; j < historyRecords.size(); j++){
				//if(historyRecords.get(j))
					
			//}
				
		}
		
		return list;
	}
	
	//Yangdi-2014-07-21
	//分页：从数据库得出分页数据
	public List<Customer> queryByPage(String hql, int offset, int pageSize){
		session = HibernateUtil.getSessionFactory().getCurrentSession();		
		List<Customer> list = null;
		List<User> userList = null;		
		Transaction tx = null;
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql).setFirstResult(offset).setMaxResults(pageSize);
			list = query.list();
			System.out.println("CustomerDao:	-->	list.saize:"+list.size());
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		return list;
	}
	
	//Yangdi-2014-07-21
	//分页：从数据库得出分页数据
	public List<CustomerListHelp> queryByPage2(String hql, int offset, int pageSize){
		session = HibernateUtil.getSessionFactory().getCurrentSession();		
		List<CustomerListHelp> list = null;
		Collection result = new ArrayList();
		
		Transaction tx = null;
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql).setFirstResult(offset).setMaxResults(pageSize);
			result = query.list();
			System.out.println("CustomerDao:	-->	list.saize:"+list.size());
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		ArrayList sList = (ArrayList)result;
		Iterator it = sList.iterator();
		CustomerListHelp tmp = new CustomerListHelp();
		while (it.hasNext()) {			
			
			Object[] o = (Object[]) it.next();
			Customer custmp = (Customer) o[0];
			User usertmp = (User) o[1];
			tmp.setCustomer(custmp);
			tmp.setUser(usertmp);
			System.out.println("--> cusName:"+custmp.getCustomerName()+" user name:"+usertmp.getUserName());
			list.add(tmp);			
			}		
		
		return list;
	}	
	
	//Yangdi-2014-7-23
	//通过制定查询语句得到客户列表
	public List<Customer> getCustomersQueryList2(String hql){
		session = HibernateUtil.getSessionFactory().getCurrentSession();		
		List<Customer> list = null;
		Collection result = new ArrayList();
		Transaction tx = null;
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			result = query.list();
			System.out.println("CustomerDao:	-->	list.saize:"+list.size());
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		ArrayList sList = (ArrayList)result;
		Iterator it = sList.iterator();
		//CustomerListHelp tmp = new CustomerListHelp();
		while (it.hasNext()) {			
			
			Object[] o = (Object[]) it.next();
			Customer custmp = (Customer) o[0];
			User usertmp = (User) o[1];
			//tmp.setCustomer(custmp);
			//tmp.setUser(usertmp);
			System.out.println("--> cusName:"+custmp.getCustomerName()+" user name:"+usertmp.getUserName());
			list.add(custmp);			
			}				
		
		return list;
	}
	
	//Yangdi-2014-7-21
	//通过制定查询语句得到客户列表
	public List<Customer> getCustomersQueryList(String hql){
		session = HibernateUtil.getSessionFactory().getCurrentSession();		
		List<Customer> list = null;
		Transaction tx = null;
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			list = query.list();
			//System.out.println("CustomerDao:	-->	list.saize:"+list.size());
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		return list;
	}
	
	//Yangdi-2014-07-21
	public int getAllNotLostCount(){
		return this.getNotLostCustomers().size();
	}

	// 获取客户by id
	public Customer getCustomer(String customerID) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		Customer customer = (Customer) session.get(Customer.class, customerID);
		return customer;
	}

	// 添加客户
	public boolean saveCustomer(Customer customer) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		try {
			customer.setCustomerId("000000000000000000000000000000000000");
			session.save(customer);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// 修改客户
	public boolean updateCustomer(Customer customer) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		try {
			session.update(customer);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e.getStackTrace());
			return false;
		}

		return true;
	}

	// 客户状态，  0:正常，1:申报流失，2：确认预警；3:流失暂缓，4：确认流失

	// 解除客户关系（流失客户）
	public boolean dropCustomer(Customer customer) {
		customer.setCustomerState(4);
		updateCustomer(customer);
		return true;
	}

	// 获取客户列表  未流失的客户
	//Yangdi：评论-废弃方法
	public List<Customer> getNotLostCustomers() {
		//System.out.println("[CustomerDao]:	getNotLostCustomers	-->	getin");
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		List<Customer> customers = (List<Customer>) session
				.createCriteria(Customer.class)
				.add(Restrictions.lt("customerState",4))
				.list();
		//if(customers.size()==0)
			//System.out.println("[CustomerDao]:	getNotLostCustomers	-->	customer.size=0");
		//System.out.println("[CustomerDao]:	getNotLostCustomers	-->	getout");
		return customers;
	}
	
	// 获取客户列表 申报流失的客户
	public List<Customer> getMayLostCustomers() {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		List<Customer> customers = (List<Customer>) session
				.createCriteria(Customer.class)
				.add(Restrictions.eq("customerState", 1))
				.list();
		return customers;
	}
	// 获取客户列表 预警的客户
	public List<Customer> getWarnCustomers() {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		List<Customer> customers = (List<Customer>) session
				.createCriteria(Customer.class)
				.add(Restrictions.eq("customerState", 2))
				.list();
		return customers;
	}
	
	// 获取客户列表 流失暂缓的客户
	public List<Customer> getLostPauseCustomers() {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		List<Customer> customers = (List<Customer>) session
				.createCriteria(Customer.class)
				.add(Restrictions.eq("customerState", 3))
				.list();
		return customers;
	}
}
