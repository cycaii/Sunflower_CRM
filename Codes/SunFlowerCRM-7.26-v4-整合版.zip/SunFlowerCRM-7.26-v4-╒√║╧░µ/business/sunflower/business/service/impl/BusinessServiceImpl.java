package sunflower.business.service.impl;

import java.util.List;

import sunflower.business.dao.BusinessDao;
import sunflower.business.entity.Business;
import sunflower.business.service.BusinessService;
import sunflower.user.entity.User;

public class BusinessServiceImpl implements BusinessService {
	BusinessDao bd = new BusinessDao();

	@Override
	public Business getBusiness(String businessID) {
		return bd.getBusiness(businessID);
	}

	@Override
	public boolean addBusiness(Business business) {
		return bd.saveBusiness(business);
	}

	@Override
	public boolean updateBusiness(Business business) {
		return bd.updateBusiness(business);
	}

	@Override
	public boolean dropBusiness(Business business) {
		return bd.dropBusiness(business);
	}

	@Override
	public List<Business> getAvailBusinesses() {
		return bd.getAvailBusinesses();
	}

	@Override
	public List<Business> getBusinessByPage(int page, int record_per_page) {
		return bd.getBusinessByPage(page, record_per_page);
	}

	public List<Business> getManagerBusinesses(User user) {
		return bd.getManagerBusinesses(user);
	}

	@Override
	public List<Business> getAllBusinesses() {
		return bd.getAllBusinesses();
	}

	@Override
	public List<Business> getSortedBusinessList(String sortType, User user) {
		return bd.getSortedBusinessList(sortType, user);
	}
}
