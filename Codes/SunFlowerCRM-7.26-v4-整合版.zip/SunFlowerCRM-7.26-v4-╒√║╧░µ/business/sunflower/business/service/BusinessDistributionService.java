package sunflower.business.service;

import java.util.ArrayList;
import java.util.List;

import sunflower.business.entity.BusinessDistribution;
import sunflower.user.entity.User;

public interface BusinessDistributionService {
	public BusinessDistribution getBusinessDistribution(
			String businessDistributionID);

	public boolean addBusinessDistribution(
			BusinessDistribution businessDistribution);

	public boolean updateBusinessDistribution(
			BusinessDistribution businessDistribution);

	public boolean dropBusinessDistribution(
			BusinessDistribution businessDistribution);

	public List<BusinessDistribution> getAllBusinessDistributions();

	public List<BusinessDistribution> getNewBusinessDistributions();

	public List<BusinessDistribution> getDistributedBusinessDistributions();

	public List<BusinessDistribution> getManagerDistributedBusinessDistributions(
			User user);

	public List<BusinessDistribution> getDealedBusinessDistributions();

	public List<BusinessDistribution> getManagerDealedBusinessDistributions(
			User user);

	public List<BusinessDistribution> getFinishedBusinessDistributions();

	public List<BusinessDistribution> getManagerFinishedBusinessDistributions(
			User user);

	public  List<BusinessDistribution> getSortedBusinessDistributionList(
			String sortType, User currentUser,int state);
}
