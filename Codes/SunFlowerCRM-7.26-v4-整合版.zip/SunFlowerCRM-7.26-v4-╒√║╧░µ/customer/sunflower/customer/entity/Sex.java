package sunflower.customer.entity;

public class Sex {
	
	private String sexId;
	private String sexName;
	
	public Sex(String sexId, String sexName){
		this.sexId = sexId;
		this.sexName = sexName;
	}
	
	public String getSexId() {
		return sexId;
	}
	public void setSexId(String sexId) {
		this.sexId = sexId;
	}
	public String getSexName() {
		return sexName;
	}
	public void setSexName(String sexName) {
		this.sexName = sexName;
	}
	
	

}
