package sunflower.customer.action;
//===========================
//废弃的类
//===========================
import java.util.List;

import org.apache.struts2.ServletActionContext;

import sunflower.customer.entity.Customer;
import sunflower.customer.entity.HistoryRecord;
import sunflower.customer.service.HistoryRecordService;
import sunflower.customer.service.impl.HistoryRecordServiceImpl;

import com.opensymphony.xwork2.ActionSupport;

public class HistoryAction extends ActionSupport {
	
	private Customer customer;
	private List<HistoryRecord> historyRecords;
	HistoryRecordService historyRecordService;
    
	public HistoryAction() {
		//System.out.println("CustomerAction:  CustomerAction()	-->	getin");
		historyRecordService = (HistoryRecordService) ServletActionContext.getRequest()
				.getSession().getAttribute("historyRecordService");
		if (historyRecordService == null) {
			historyRecordService = new HistoryRecordServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("historyRecordService", historyRecordService);
		}
	}
	
	public String getCustomerHistoryRecords(){
		System.out.println("-->	1我在这里");
		//customerName = new String(customerName);
		//new string();
		historyRecords = historyRecordService.getCustomerHistoryRecords(customer);
		
		System.out.println("-->	我在这里");
		
		return "getCustomerHistoryRecords";
	} 
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public List<HistoryRecord> getHistoryRecords() {
		return historyRecords;
	}
	public void setHistoryRecords(List<HistoryRecord> historyRecords) {
		this.historyRecords = historyRecords;
	}

}
