package sunflower.customer.action;
//Yangdi-2014-7-24
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import sunflower.customer.entity.Customer;
import sunflower.customer.entity.CustomerPerson;
import sunflower.customer.entity.PageBean;
import sunflower.customer.entity.Sex;
import sunflower.customer.service.CustomerPersonService;
import sunflower.customer.service.CustomerService;
import sunflower.customer.service.impl.CustomerPersonServiceImpl;
import sunflower.customer.service.impl.CustomerServiceImpl;

import com.opensymphony.xwork2.ActionSupport;

public class CustomerPersonAction extends ActionSupport {
	
	//for pagging
	private int page;
	private String sortFlag;	
	private String searchCusKey;
	
	private static final long serialVersionUID = 1L;
	private String customerId;
	private String customerName;
	private Customer customer;
	private List<CustomerPerson> customerPersonList;
	
	CustomerPersonService customerPersonService;
	
	//for editContacts.jsp
	private String customerPersonId;
	private CustomerPerson customerPerson;
	private String sex; 
	private List<Sex> sexList;
	
	public CustomerPersonAction(){
		customerPersonService = (CustomerPersonService) ServletActionContext.getRequest()
				.getSession().getAttribute("customerPersonService");
		if (customerPersonService == null) {
			customerPersonService = new CustomerPersonServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("customerPersonService", customerPersonService);
		}
		
		sexList = new ArrayList();
		sexList.add(new Sex("0","女"));
		sexList.add(new Sex("1","男"));
	}
	
	//添加客户联系人
	public String addCustomerPerson(){
		customerPerson = new CustomerPerson();
		return "addCustomerPerson";
	}
	
	//进入联系人编辑页面
	//在contactList.jsp->点击添加联系人
	public String saveAddCustomerPerson() throws UnsupportedEncodingException{
		customerName = new String(customerName.getBytes("ISO-8859-1"),"UTF8");
		
		if(sex == "Female")
		{
			customerPerson.setCustomerPersonSex(1);
		}
		if(sex == "Male")
		{
			customerPerson.setCustomerPersonSex(0);
		}
		
		CustomerService customerService = new CustomerServiceImpl();
		customer = customerService.getCustomer(customerId);
		
		customerPerson.setCustomer(customer);
		
		boolean result = customerPersonService.addCustomerPerson(customerPerson);
		
		if (result == false)
		{
			addActionMessage("<script>alert('添加失败！请重新尝试修改');</script>");
			
			return "addCustomerPersonFail";
		}
		else
		{
			addActionMessage("<script>alert('添加成功！');"
					+ "window.location.href='customerPerson_getCustomerPersonList.action?customerId="+customerId+"&customerName="+customerName+"'</script>");

			return "addCustomerPersonSuccess";
		}
		
	}

	//得到客户额联系人列表
	//在home.jsp 或 topNavigation.jsp->点击客户列表，执行
	public String getCustomerPersonList() throws UnsupportedEncodingException{
		customerName = new String(customerName.getBytes("ISO-8859-1"),"UTF8");
		
		String hql;
		hql = "from CustomerPerson where customer_id=?";
		
		PageBean pageBean = customerPersonService.getPageBean(6, page, hql, sortFlag, searchCusKey, customerId, customerName); 
        HttpServletRequest request = ServletActionContext.getRequest();        
        request.setAttribute("pageBean", pageBean);
        
		return "getCustomerPersonList";
	}

	//删除客户联系人
	//在contactList.jsp->点击删除后执行此方法
	public String delete() throws UnsupportedEncodingException{
		
		customerName = new String(customerName.getBytes("ISO-8859-1"),"UTF8");
		
		boolean result = customerPersonService.deleteCustomerPerosonById(customerPersonId);
		
		if (result == false)
		{
			addActionMessage("<script>alert('删除失败！请重新尝试修改');</script>");
			
			return "deleteFail";
		}
		else
		{
			addActionMessage("<script>alert('删除成功！');"
					+ "window.location.href='customerPerson_getCustomerPersonList.action?customerId="+customerId+"&customerName="+customerName+"'</script>");

			return "deleteSuccess";
		}
	}

	//编辑客户联系人
	//在contactList->点击编辑后执行此方法，进入编辑页面
	public String edit() throws UnsupportedEncodingException{
		
		 customerName = new String(customerName.getBytes("ISO-8859-1"),"UTF8");
		 customerPerson = customerPersonService.getCustomerPersonById(customerPersonId);
		 HttpServletRequest request = ServletActionContext.getRequest();        
	     request.setAttribute("customerPerson", customerPerson);
	     if(customerPerson.getCustomerPersonSex()==0)
	    	 sex="Male";
	     else if(customerPerson.getCustomerPersonSex()==1)
	    	 sex="Female";
	     else
	    	 sex="NoChoice";
		
		return "edit";
	}

	//保存编辑
	//在editContacts.jsp->点击保存按钮后，执行此方法
	public String saveEdit() throws UnsupportedEncodingException{
		
		if(sex == "Female")
			customerPerson.setCustomerPersonSex(1);
		if(sex == "Male")
			customerPerson.setCustomerPersonSex(0);
		
		boolean result = customerPersonService.saveEdit(customerPerson);
		
		if (result == false)
		{
			addActionMessage("<script>alert('修改失败！请重新尝试修改');</script>");
			
			return "saveEditFail";
		}
		else
		{			
			addActionMessage("<script>alert('修改成功！');"
					+ "window.location.href='customerPerson_getCustomerPersonList.action?customerId="+customerId+"&customerName="+customerName+"'</script>");

			return "saveEditSuccess";
		}
	}
	
//=======================================================================
//Getter & Setter
//=======================================================================
	
	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public String getSortFlag() {
		return sortFlag;
	}

	public void setSortFlag(String sortFlag) {
		this.sortFlag = sortFlag;
	}

	public String getSearchCusKey() {
		return searchCusKey;
	}

	public void setSearchCusKey(String searchCusKey) {
		this.searchCusKey = searchCusKey;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public CustomerPersonService getCustomerPersonService() {
		return customerPersonService;
	}

	public void setCustomerPersonService(CustomerPersonService customerPersonService) {
		this.customerPersonService = customerPersonService;
	}

	public void setCustomerPersonList(List<CustomerPerson> customerPersonList) {
		this.customerPersonList = customerPersonList;
	}

	public String getCustomerPersonId() {
		return customerPersonId;
	}

	public void setCustomerPersonId(String customerPersonId) {
		this.customerPersonId = customerPersonId;
	}

	public CustomerPerson getCustomerPerson() {
		return customerPerson;
	}

	public void setCustomerPerson(CustomerPerson customerPerson) {
		this.customerPerson = customerPerson;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public List<Sex> getSexList() {
		return sexList;
	}

	public void setSexList(List<Sex> sexList) {
		this.sexList = sexList;
	}	
	
	
}
