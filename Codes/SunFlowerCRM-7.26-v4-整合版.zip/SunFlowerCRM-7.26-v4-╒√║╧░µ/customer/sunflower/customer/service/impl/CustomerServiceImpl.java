package sunflower.customer.service.impl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import sunflower.customer.dao.CustomerDao;
import sunflower.customer.entity.Customer;
import sunflower.customer.entity.CustomerListHelp;
import sunflower.customer.entity.HistoryRecord;
import sunflower.customer.entity.PageBean;
import sunflower.customer.service.CustomerService;
import sunflower.customer.service.HistoryRecordService;


public class CustomerServiceImpl implements CustomerService {
	CustomerDao cd = new CustomerDao();
	
	//创建客户
	@Override
	public Customer getNewCustomer(){
		return cd.getNewCustomer();
	}
	
	//Yangdi-2014-7-21
	//通过用户列表查询得到每一个用户的历史记录列表
	public List<HistoryRecord> getCustomerLatestRecord(List<Customer> customers){	
		
		List<HistoryRecord> historyRecords = new ArrayList<HistoryRecord>();
		HistoryRecordService historyRecordService = new HistoryRecordServiceImpl();
		List<HistoryRecord> recordTmpList;
		
		for(int i = 0; i < customers.size(); i++){
			recordTmpList = historyRecordService.getCustomerHistoryRecords(customers.get(i));
			if(recordTmpList.size()!=0)
			{
				historyRecords.add(recordTmpList.get(0));
				System.out.println("-->	date:"+recordTmpList.get(0).getHistoryRecordDate());
			}
			else
				historyRecords.add(null);
		}		
		
		return historyRecords;
	}
	
	//Yangdi-2014-7-21
	//分页：提供相应的查询语句，每一页显示的记录数据，当前页码，来得到相应的显示以及查询列表
	@Override
	public PageBean getPageBean(int pageSize, int page, String hql, String sortFlag, String searchCusKey)
    {
        PageBean pageBean = new PageBean();
        
        //得到查询得到的记录的数目
        String currentSortFlag = pageBean.getsf(sortFlag);
        String currentSearchKey = pageBean.getsk(searchCusKey);
        if(currentSearchKey == null || "".equals(currentSearchKey)){
        	hql=hql + currentSortFlag;}
        else       
        	hql = hql + " and customer_name like '%"+ currentSearchKey + "%' " + currentSortFlag;
        
        System.out.println("--> sSQL="+hql);
        
        int allRows = cd.getCustomersQueryList(hql).size();
        //得到总页数
        int totalPage = pageBean.getTotalPages(pageSize, allRows);
        //达到当前显示页面
        int currentPage = pageBean.getCurPage(page);
        //得到当前页面在数据库查记录中的位置
        int offset = pageBean.getCurrentPageOffset(pageSize, currentPage);
        //得到查询后客户列表
        List<Customer> list = cd.queryByPage(hql, offset, pageSize);

        pageBean.setList(list);
        
        pageBean.setAllRows(allRows);
        pageBean.setCurrentPage(currentPage);
        pageBean.setTotalPage(totalPage);
        pageBean.setSortFlag(currentSortFlag);
        pageBean.setSearchCusKey(currentSearchKey);
        
        return pageBean;
    }
	
	//Yangdi-2014-7-22
	//分页：提供相应的查询语句，每一页显示的记录数据，当前页码，来得到相应的显示以及查询列表
	@Override
	public PageBean getPageBean2(int pageSize, int page, String hql, String sortFlag, String searchCusKey)
    {
        PageBean pageBean = new PageBean();
        
        //得到查询得到的记录的数目
        String currentSortFlag = pageBean.getsf(sortFlag);
        String currentSearchKey = pageBean.getsk(searchCusKey);
        if(currentSearchKey == null || "".equals(currentSearchKey))
        	hql=hql + currentSortFlag;
        else      	
        	hql = hql + " and customer_name like '%"+ currentSearchKey + "%' " + currentSortFlag;
        
        int allRows = cd.getCustomersQueryList(hql).size();
        //得到总页数
        int totalPage = pageBean.getTotalPages(pageSize, allRows);
        //达到当前显示页面
        int currentPage = pageBean.getCurPage(page);
        //得到当前页面在数据库查记录中的位置
        int offset = pageBean.getCurrentPageOffset(pageSize, currentPage);
        //得到查询后客户列表
        List<Customer> list = cd.queryByPage(hql, offset, pageSize);
        //得到每一个客户的最近交易记录列表
        List<HistoryRecord> latestRecordList = this.getCustomerLatestRecord(list);
        
        pageBean.setLatestRecordList(latestRecordList);
        pageBean.setList(list);
        //将客户以及对应的最近交易时间记录到map
        Map map = pageBean.setMap2(list, latestRecordList);
       
        pageBean.setAllRows(allRows);
        pageBean.setCurrentPage(currentPage);
        pageBean.setTotalPage(totalPage);
        pageBean.setSortFlag(currentSortFlag);
        pageBean.setSearchCusKey(currentSearchKey);
        
        return pageBean;
    }

	@Override
	public Customer getCustomer(String customerID) {
		return cd.getCustomer(customerID);
	}

	@Override
	public boolean addCustomer(Customer customer) {
		return cd.saveCustomer(customer);
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		return cd.updateCustomer(customer);
	}

	@Override
	public boolean dropCustomer(Customer customer) {
		return cd.dropCustomer(customer);
	}

	@Override
	public List<Customer> getNotLostCustomers() {
		System.out.println("CustomerService:	getNotLostCustomers	-->	getin");
		return cd.getNotLostCustomers();
	}

	@Override
	public List<Customer> getMayLostCustomers() {
		return cd.getMayLostCustomers();
	}

	@Override
	public List<Customer> getWarnCustomers() {
		return cd.getWarnCustomers();
	}

	@Override
	public List<Customer> getLostPauseCustomers() {
		return cd.getLostPauseCustomers();
	}

}
