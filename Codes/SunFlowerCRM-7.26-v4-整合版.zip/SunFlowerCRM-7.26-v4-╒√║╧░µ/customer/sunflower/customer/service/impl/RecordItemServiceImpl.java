package sunflower.customer.service.impl;

import java.util.List;

import sunflower.customer.dao.HistoryRecordDao;
import sunflower.customer.dao.RecordItemDao;
import sunflower.customer.entity.HistoryRecord;
import sunflower.customer.entity.PageBean;
import sunflower.customer.entity.RecordItem;
import sunflower.customer.service.RecordItemService;

public class RecordItemServiceImpl implements RecordItemService {
	RecordItemDao rid = new RecordItemDao();
	
	//Yangdi-2014-7-21
	//分页：提供相应的查询语句，每一页显示的记录数据，当前页码，来得到相应的显示以及查询列表
	@Override
	public PageBean getPageBean(int pageSize, int page, String hql, String sortFlag, String searchCusKey, String historyRecordId)
    {
        PageBean pageBean = new PageBean();
        
        //得到查询得到的记录的数目
        String currentSortFlag = pageBean.getsf(sortFlag);
        String currentSearchKey = pageBean.getsk(searchCusKey);
        if(currentSortFlag!=null)
        	hql=hql + currentSortFlag;
        
        int allRows = rid.getRecordItemCount(hql, historyRecordId);
        //得到总页数
        int totalPage = pageBean.getTotalPages(pageSize, allRows);
        //达到当前显示页面
        int currentPage = pageBean.getCurPage(page);
        //得到当前页面在数据库查记录中的位置
        int offset = pageBean.getCurrentPageOffset(pageSize, currentPage);
        //得到查询后客户列表
        List<RecordItem> list = rid.queryByPage(hql, offset, pageSize, historyRecordId);

        HistoryRecord historyRecord = rid.getHistoryRecordById(historyRecordId);
        pageBean.setHistoryRecord(historyRecord);
        System.out.println("--> RrcordItemSerive:"+historyRecord.getHistoryRecordId());
        
        pageBean.setRecordItemList(list);

        pageBean.setAllRows(allRows);
        pageBean.setCurrentPage(currentPage);
        pageBean.setTotalPage(totalPage);
        pageBean.setSortFlag(currentSortFlag);
        pageBean.setSearchCusKey(currentSearchKey);
       
        return pageBean;
    }


}
