package sunflower.customer.service;

import sunflower.customer.entity.PageBean;

public interface RecordItemService {
	
	public PageBean getPageBean(int pageSize, int page, String hql, String sortFlag, String searchCusKey, String historyRecordId);

	
}
