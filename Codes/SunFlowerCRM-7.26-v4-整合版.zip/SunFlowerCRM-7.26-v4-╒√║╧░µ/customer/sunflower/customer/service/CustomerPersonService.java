package sunflower.customer.service;

import sunflower.customer.entity.CustomerPerson;
import sunflower.customer.entity.PageBean;

public interface CustomerPersonService {
	
	public boolean deleteCustomerPerosonById(String customerPersonId);
	
	public boolean saveEdit(CustomerPerson customerPerson);
	
	public PageBean getPageBean(int pageSize, int page, String hql, String sortFlag, String searchCusKey, String customerId, String customerName);	
	
	public CustomerPerson getCustomerPersonById(String customerPersonId);

	public boolean addCustomerPerson(CustomerPerson customerPerson);

	public boolean updateCustomerPerson(CustomerPerson customerPerson);

	public boolean deleteCustomerPerson(CustomerPerson customerPerson);

}
