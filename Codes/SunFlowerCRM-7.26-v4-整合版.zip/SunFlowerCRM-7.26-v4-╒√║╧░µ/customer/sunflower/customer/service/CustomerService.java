package sunflower.customer.service;

import java.util.List;

import sunflower.customer.entity.Customer;
import sunflower.customer.entity.HistoryRecord;
import sunflower.customer.entity.PageBean;


public interface CustomerService {
	
	public Customer getNewCustomer();
	
	//Yangdi-2014-7-21
	public PageBean getPageBean(int pageSize, int page, String hql, String sortFlag, String searchCusKey);
	public PageBean getPageBean2(int pageSize, int page, String hql, String sortFlag, String searchCusKey);
	
	//Yangdi-2014-7-21
	public List<HistoryRecord> getCustomerLatestRecord(List<Customer> customers);
	
	public Customer getCustomer(String customerID);

	public boolean addCustomer(Customer customer);

	public boolean updateCustomer(Customer customer);

	public boolean dropCustomer(Customer customer);

	public List<Customer> getNotLostCustomers();

	public List<Customer> getMayLostCustomers();

	public List<Customer> getWarnCustomers();

	public List<Customer> getLostPauseCustomers();
}
