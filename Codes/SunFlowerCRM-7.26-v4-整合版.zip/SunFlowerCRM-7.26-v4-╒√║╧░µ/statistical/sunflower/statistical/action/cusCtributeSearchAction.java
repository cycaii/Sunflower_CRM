package sunflower.statistical.action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import sunflower.customer.entity.Customer;
import sunflower.statistical.entity.cusCtriAnalyze;
import sunflower.statistical.service.statisticService;
import sunflower.statistical.service.impl.statisticServiceImpl;

import com.opensymphony.xwork2.ActionSupport;
public class cusCtributeSearchAction extends ActionSupport{

	private static final long serialVersionUID = 1L;
	private Customer cust = null;
	private ArrayList<cusCtriAnalyze> cus = new ArrayList<cusCtriAnalyze>();
	statisticService service = new statisticServiceImpl();
	private String ccname;
	public String cusCtributeSearch(){
		ccname = ServletActionContext.getRequest().getParameter("ccname");
		cust = service.getCustomerByName(ccname);
		System.out.println(ccname);
		System.out.println(cust.getCustomerName());
		if(cust!=null){
			cusCtriAnalyze cca = new cusCtriAnalyze();
			cca.setCusName(cust.getCustomerName());
			double sum = 0;
			for(int i = 0;i<cust.getHistoryRecords().size();i++){
				for(int j = 0;j<cust.getHistoryRecords().get(i).getRecordItems().size();j++){
					sum = sum + cust.getHistoryRecords().get(i).getRecordItems().get(j).getRecordItemTotalPrice();
				}
			}
			cca.setTotal_price(sum);
			cus.add(cca);
			return "cusCtributeSearch";
		}else{
			return "Nobody";
		}
	}
	
	public Customer getCust() {
		return cust;
	}
	public void setCust(Customer cust) {
		this.cust = cust;
	}
	public ArrayList<cusCtriAnalyze> getCus() {
		return cus;
	}
	public void setCus(ArrayList<cusCtriAnalyze> cus) {
		this.cus = cus;
	}

	public String getCcname() {
		return ccname;
	}

	public void setCcname(String ccname) {
		this.ccname = ccname;
	}

}
