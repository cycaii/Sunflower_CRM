package sunflower.statistical.action;


import java.util.ArrayList;

import sunflower.customer.entity.Customer;
import sunflower.statistical.entity.cusCtriAnalyze;
import sunflower.statistical.service.statisticService;
import sunflower.statistical.service.impl.statisticServiceImpl;

import java.util.Collections;
import java.util.Comparator;
import com.opensymphony.xwork2.ActionSupport;
public class cusCtrPriceSortAction extends ActionSupport{

	private static final long serialVersionUID = 1L;
	
	private ArrayList<Customer> customers  = new ArrayList<Customer>(); 
    private ArrayList<cusCtriAnalyze> cus = new ArrayList<cusCtriAnalyze>();
	statisticService service = new statisticServiceImpl();

	public String cusCtrPriceSort(){
		customers = service.getCustomers();
		for(int i = 0;i<customers.size();i++){
			cusCtriAnalyze ele = new cusCtriAnalyze();
			ele.setCusName(customers.get(i).getCustomerName());
			cus.add(ele);
		} 
		for(int j = 0;j<customers.size();j++){
			double sum = 0;
			for(int k = 0;k<customers.get(j).getHistoryRecords().size();k++){
				for(int l = 0;l<customers.get(j).getHistoryRecords().get(k).getRecordItems().size();l++){
					sum = sum + customers.get(j).getHistoryRecords().get(k).getRecordItems().get(l).getRecordItemTotalPrice();
				}
			}
			cus.get(j).setTotal_price(sum);
		}
		
		Collections.sort(cus, new Comparator<cusCtriAnalyze>(){
			public int compare(cusCtriAnalyze c1, cusCtriAnalyze c2){
				if(c1 != null && c2 != null){
					if(c1.getTotal_price() > c2.getTotal_price()){
						return 1;
					}else if(c1.getTotal_price() < c2.getTotal_price()){
						return -1;
					}
				}
				return 0;
			}
		});
		
		return "cusCtrPriceSort";
	}
	public ArrayList<Customer> getCustomers() {
		return customers;
	}
	public void setCustomers(ArrayList<Customer> customers) {
		this.customers = customers;
	}
	public ArrayList<cusCtriAnalyze> getCus() {
		return cus;
	}
	public void setCus(ArrayList<cusCtriAnalyze> cus) {
		this.cus = cus;
	}
}
