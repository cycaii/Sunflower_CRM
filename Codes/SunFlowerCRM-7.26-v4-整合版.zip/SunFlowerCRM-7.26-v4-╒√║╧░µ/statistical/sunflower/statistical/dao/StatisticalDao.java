package sunflower.statistical.dao;

import java.util.List;

import javax.persistence.Query;

import sunflower.util.support.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import sunflower.business.entity.Business;
import sunflower.statistical.entity.*;
public class StatisticalDao {
	private Session session;
	
	public List<LostAnalyze> getLostAnalyzeList(String query_string)
	{
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		org.hibernate.Query query = session.createQuery(query_string);
		List<LostAnalyze> lost_analyze_list = query.list();
		return lost_analyze_list;
	}
	
	//分页函数，统一从第一页开始
	public List<LostAnalyze> getLostAnalyzeListByPage(int current_page, int record_per_page, String query_string)
	{
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
//		org.hibernate.Query query = session.createQuery("from LostAnalyze");
		org.hibernate.Query	query = session.createQuery(query_string);
		query.setFirstResult(record_per_page * (current_page - 1) );
		query.setMaxResults(record_per_page);
		List<LostAnalyze> lost_analyze_list = query.list();
		return lost_analyze_list;
	}
	
	public List<BusinessAnalyze> getBusinessAnalyze(String query_string)
	{
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		org.hibernate.Query query = session.createQuery(query_string);
		List<BusinessAnalyze> business_analyze_list = query.list();
		return business_analyze_list;
	}
	
	//分页函数，统一从第一页开始
	public List<BusinessAnalyze> getBusinessAnalyzeByPage(int current_page, int record_per_page, String query_string)
	{
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
//		org.hibernate.Query query = session.createQuery("from LostAnalyze");
		org.hibernate.Query	query = session.createQuery(query_string);
		query.setFirstResult(record_per_page * (current_page - 1) );
		query.setMaxResults(record_per_page);
		List<BusinessAnalyze> business_analyze_list = query.list();
		return business_analyze_list;
	}
	
	public List<ComponentAnalyze> getComponentAnalyze(String query_string)
	{
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		org.hibernate.Query query = session.createQuery(query_string);
		List<ComponentAnalyze> component_analyze_list = query.list();
		return component_analyze_list;
	}
	
	//分页函数，统一从第一页开始
	public List<ComponentAnalyze> getComponentAnalyzeByPage(int current_page, int record_per_page, String query_string)
	{
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
//		org.hibernate.Query query = session.createQuery("from LostAnalyze");
		org.hibernate.Query	query = session.createQuery(query_string);
		query.setFirstResult(record_per_page * (current_page - 1) );
		query.setMaxResults(record_per_page);
		List<ComponentAnalyze> component_analyze_list = query.list();
		return component_analyze_list;
	}




}
