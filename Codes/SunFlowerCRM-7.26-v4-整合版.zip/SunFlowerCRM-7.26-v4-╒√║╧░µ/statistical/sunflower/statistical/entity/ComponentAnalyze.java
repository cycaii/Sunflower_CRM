package sunflower.statistical.entity;

import java.io.Serializable;

public class ComponentAnalyze implements Serializable{

	/**
	 * 
	 */
	public ComponentAnalyze()
	{
		
	}
	private static final long serialVersionUID = 1L;
	private ComponentAnalyzeId id;
	public ComponentAnalyzeId getId() {
		return id;
	}
	public void setId(ComponentAnalyzeId id) {
		this.id = id;
	}
	
}
