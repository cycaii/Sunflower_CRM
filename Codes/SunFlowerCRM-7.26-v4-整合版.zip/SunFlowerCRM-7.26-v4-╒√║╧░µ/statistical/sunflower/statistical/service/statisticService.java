package sunflower.statistical.service;

import java.util.ArrayList;

import sunflower.customer.entity.Customer;

public interface statisticService {
	public ArrayList<Customer> getCustomers();
	public Customer getCustomerByName(String customerName);
}
