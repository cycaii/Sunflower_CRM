package sunflower.statistical.service.impl;

import java.util.List;

import sunflower.statistical.dao.StatisticalDao;
import sunflower.statistical.entity.BusinessAnalyze;
import sunflower.statistical.entity.ComponentAnalyze;
import sunflower.statistical.entity.LostAnalyze;
import sunflower.statistical.service.StatisticalService;

public class StatisticalServiceImpl implements StatisticalService {

	StatisticalDao bd = new StatisticalDao();
	@Override
	public List<LostAnalyze> getLostAnalyzeList() {
		// TODO Auto-generated method stub
		return bd.getLostAnalyzeList("from LostAnalyze");
	}
	@Override
	public List<LostAnalyze> getLostAnalyzeListByPage(int current_page,
			int record_per_page) {
		// TODO Auto-generated method stub
		return bd.getLostAnalyzeListByPage(current_page, record_per_page, "from LostAnalyze");
	}
	@Override
	public List<LostAnalyze> getLostAnalyzeListByPage_customerNameOrder(
			int current_page, int record_per_page) {
		// TODO Auto-generated method stub
		return bd.getLostAnalyzeListByPage(current_page, record_per_page, "from LostAnalyze order by id.customer_name");
	}
	@Override
	public List<LostAnalyze> getLostAnalyzeListByPage_userNameOrder(
			int current_page, int record_per_page) {
		// TODO Auto-generated method stub
		return bd.getLostAnalyzeListByPage(current_page, record_per_page, "from LostAnalyze order by id.user_name");
	}
	
	//businessAnalyze.jsp
	@Override
	public List<BusinessAnalyze> getBusinessAnalyzeListByPage(int current_page,
			int record_per_page) {
		// TODO Auto-generated method stub
		return bd.getBusinessAnalyzeByPage(current_page, record_per_page, "from BusinessAnalyze");
	}
	@Override
	public List<BusinessAnalyze> getBusinessAnalyzeListByPage_businessNumberOrder(
			int current_page, int record_per_page) {
		// TODO Auto-generated method stub
		return bd.getBusinessAnalyzeByPage(current_page, record_per_page, "from BusinessAnalyze order by id.business_count DESC");
	}
	@Override
	public List<BusinessAnalyze> getBusinessAnalyzeList() {
		// TODO Auto-generated method stub
		return bd.getBusinessAnalyze("from BusinessAnalyze");
	}
	@Override
	public List<BusinessAnalyze> getBusinessAnalyzeListByPage_businessTypeOrder(
			int current_page, int record_per_page) {
		// TODO Auto-generated method stub
		return bd.getBusinessAnalyzeByPage(current_page, record_per_page, "from BusinessAnalyze order by id.business_type DESC");
	}
	//componentAnalyze.jsp
	@Override
	public List<ComponentAnalyze> getComponentAnalyzeListByPage(int current_page,
			int record_per_page) {
		// TODO Auto-generated method stub
		return bd.getComponentAnalyzeByPage(current_page, record_per_page, "from ComponentAnalyze");
	}
	@Override
	public List<ComponentAnalyze> getComponentAnalyzeListByPage_customerNumberOrder(
			int current_page, int record_per_page) {
		// TODO Auto-generated method stub
		return bd.getComponentAnalyzeByPage(current_page, record_per_page, "from ComponentAnalyze order by id.customer_count DESC");
	}
	@Override
	public List<ComponentAnalyze> getComponentAnalyzeList() {
		// TODO Auto-generated method stub
		return bd.getComponentAnalyze("from ComponentAnalyze");
	}
	@Override
	public List<ComponentAnalyze> getComponentAnalyzeListByPage_customerLevelOrder(
			int current_page, int record_per_page) {
		// TODO Auto-generated method stub
		return bd.getComponentAnalyzeByPage(current_page, record_per_page, "from ComponentAnalyze order by id.customer_level DESC");
	}
	
}
