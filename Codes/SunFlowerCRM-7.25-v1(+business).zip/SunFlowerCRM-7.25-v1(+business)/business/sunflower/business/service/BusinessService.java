package sunflower.business.service;

import java.util.List;

import sunflower.business.entity.Business;
import sunflower.user.entity.User;

public interface BusinessService {
	public Business getBusiness(String businessID);

	public boolean addBusiness(Business business);

	public boolean updateBusiness(Business business);

	public boolean dropBusiness(Business business);

	public List<Business> getAvailBusinesses();
	
	public List<Business> getAllBusinesses();

	public List<Business> getBusinessByPage(int page, int record_per_page);

	public List<Business> getManagerBusinesses(User user);
}
