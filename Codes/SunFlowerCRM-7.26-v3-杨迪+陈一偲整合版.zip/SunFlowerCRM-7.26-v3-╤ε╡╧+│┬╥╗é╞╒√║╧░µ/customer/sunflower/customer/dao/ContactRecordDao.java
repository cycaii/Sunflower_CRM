package sunflower.customer.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import sunflower.customer.entity.ContactRecord;
import sunflower.customer.entity.CustomerPerson;
import sunflower.customer.entity.HistoryRecord;
import sunflower.util.support.HibernateUtil;

public class ContactRecordDao {
	private Session session;
	
	//通过交易记录ID删除交易记录
	public boolean deleteContactRecordById(String contactRecordId) {
		
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		
		try {
			session.delete(session.load(ContactRecord.class,
					contactRecordId));
			session.getTransaction().commit();
		} catch (Exception e) {
			return false;
		}

		return true;
	}
	
	//Yangdi-2014-7-23
	//通过制定查询语句得到客户列表
	public int getContactRecordListCount(String hql, String customerId){
		
		session = HibernateUtil.getSessionFactory().getCurrentSession();	
		List<ContactRecord> list = null;
		Transaction tx = null;
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter(0, customerId);
			list = query.list();
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		return list.size();
	}

	//Yangdi-2014-07-21
	//分页：从数据库得出分页数据
	public List<ContactRecord> queryByPage(String hql, int offset, int pageSize, String customerId){
		session = HibernateUtil.getSessionFactory().getCurrentSession();		
		List<ContactRecord> list = null;
		Transaction tx = null;
		
		try{
			tx = session.beginTransaction();
			Query query = session.createQuery(hql).setFirstResult(offset).setMaxResults(pageSize);
			query.setParameter(0, customerId);
			list = query.list();
			tx.commit();
		}catch(Exception e){
			if(tx != null)
            {
                tx.rollback();
            }            
            e.printStackTrace();
		}
		
		return list;
	}
	

	// 获取交往记录by id
	public ContactRecord getContactRecord(String contactRecordID) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		ContactRecord contactRecord = (ContactRecord) session.get(
				ContactRecord.class, contactRecordID);
		return contactRecord;
	}

	// 添加交往记录
	public boolean saveContactRecord(ContactRecord contactRecord) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		try {
			contactRecord
					.setContactRecordId("000000000000000000000000000000000000");
			session.save(contactRecord);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// 修改交往记录
	public boolean updateContactRecord(ContactRecord contactRecord) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		try {
			session.update(contactRecord);
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e.getStackTrace());
			return false;
		}

		return true;
	}

	// 删除交往记录
	public boolean deleteContactRecord(ContactRecord contactRecord) {
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		try {
			session.delete(session.load(ContactRecord.class,
					contactRecord.getContactRecordId()));
			session.getTransaction().commit();
		} catch (Exception e) {
			return false;
		}

		return true;
	}
}
