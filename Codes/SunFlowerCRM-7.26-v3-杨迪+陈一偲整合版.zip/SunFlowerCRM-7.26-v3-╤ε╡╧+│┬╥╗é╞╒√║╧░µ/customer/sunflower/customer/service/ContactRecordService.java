package sunflower.customer.service;

import sunflower.customer.entity.ContactRecord;
import sunflower.customer.entity.PageBean;

public interface ContactRecordService {
	
	public boolean deleteContactRecordById(String contactRecordId);
	
	public boolean saveEdit(ContactRecord contactRecord);
	
	public PageBean getPageBean(int pageSize, int page, String hql, String sortFlag, String searchCusKey, String customerId, String customerName);
	
	public ContactRecord getContactRecord(String contactRecordID);

	public boolean addContactRecord(ContactRecord contactRecord);

	public boolean updateContactRecord(ContactRecord contactRecord);

	public boolean deleteContactRecord(ContactRecord contactRecord);

}
