package sunflower.business.action;

import java.util.Date;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import sunflower.business.entity.Business;
import sunflower.business.entity.BusinessDistribution;
import sunflower.business.service.BusinessDistributionService;
import sunflower.business.service.BusinessService;
import sunflower.business.service.impl.BusinessDistributionServiceImpl;
import sunflower.business.service.impl.BusinessServiceImpl;
import sunflower.customer.entity.Customer;
import sunflower.customer.service.CustomerService;
import sunflower.customer.service.impl.CustomerServiceImpl;
import sunflower.sales.entity.Sale;
import sunflower.user.entity.User;

import com.opensymphony.xwork2.ActionSupport;

public class BusinessAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	private BusinessService businessService;
	private BusinessDistributionService businessDistributionService;
	CustomerService customerService;
	private User currentUser;
	private String businessID;
	private String customerID;
	private String businessDistributionID;
	private Business business;// 销售机会
	private BusinessDistribution businessDistribution;
	private List<Business> businesslist;
	private List<BusinessDistribution> businessDistributionlist;
	private List<Customer> customerlist;

	private String sortType;// 排序方式
	private int state;// 服务分配状态
	private int totalPage;
	private int page;
	private int isSort;// 排序与否的标志位， 默认否-0

	public BusinessAction() {
		businessService = (BusinessService) ServletActionContext.getRequest()
				.getSession().getAttribute("businessService");
		if (businessService == null) {
			businessService = new BusinessServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("businessService", businessService);
		}

		businessDistributionService = (BusinessDistributionService) ServletActionContext
				.getRequest().getSession()
				.getAttribute("businessDistributionService");
		if (businessDistributionService == null) {
			businessDistributionService = new BusinessDistributionServiceImpl();
			ServletActionContext
					.getRequest()
					.getSession()
					.setAttribute("businessDistributionService",
							businessDistributionService);
		}

		customerService = (CustomerService) ServletActionContext.getRequest()
				.getSession().getAttribute("customerService");
		if (customerService == null) {
			customerService = new CustomerServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("customerService", customerService);
		}
		setCurrentUser((User) ServletActionContext.getRequest().getSession()
				.getAttribute("currentUser"));
		isSort = 0;
	}

	// TODO Auto-generated method stub
	// 服务分页 ，默认第一页
	private List<Business> businessPageList(List<Business> businesslist,
			int page) {
		if (page > 0)
			;
		else
			page = 1;
		int start = (page - 1) * 10, end = page * 10;

		if (businesslist.size() < end)
			end = businesslist.size();
		System.out.println("businesslist--size:" + businesslist.size());
		System.out.println("businessPageList---page start:" + start + "  end:"
				+ end);
		businesslist = businesslist.subList(start, end);// 包含起点不包含终点

		return businesslist;
	}

	// 服务分配分页 ，默认第一页
	private List<BusinessDistribution> businessDistributionPageList(
			List<BusinessDistribution> businessDistributionlist, int page) {
		if (page > 0)
			;
		else
			page = 1;
		int start = (page - 1) * 10, end = page * 10;

		if (businessDistributionlist.size() < end)
			end = businessDistributionlist.size();
		System.out.println("businessDistributionlist---size:"
				+ businessDistributionlist.size());
		System.out.println("businessDistributionPageList---page start:" + start
				+ "  end:" + end);

		businessDistributionlist = businessDistributionlist.subList(start, end);// 包含起点不包含终点

		return businessDistributionlist;
	}

	/* =======================服务列表======================= */
	// TODO Auto-generated method stub

	// 进入服务列表
	public String viewBusinessList() {
		if (page > 0)
			;
		else
			page = 1;
		isSort = 0;
		if (currentUser.getUserLevel() == 2) {
			businesslist = businessService.getAllBusinesses();
			totalPage = (businesslist.size() - 1) / 10 + 1;
			businesslist = businessPageList(businesslist, page);
			return "businessListforDirector";
		} else {
			businesslist = businessService.getManagerBusinesses(currentUser);
			totalPage = (businesslist.size() - 1) / 10 + 1;
			businesslist = businessPageList(businesslist, page);
			return "businessListforManager";
		}
	}

	// 排序的服务列表
	public String sortBusinessList() {
		System.out.println("sortBusinessList-sortType:" + sortType + "  page:"
				+ page);
		businesslist = businessService.getSortedBusinessList(sortType,
				currentUser);
		// 分页
		if (page > 0)
			;
		else
			page = 1;
		totalPage = (businesslist.size() - 1) / 10 + 1;
		businesslist = businessPageList(businesslist, page);
		isSort = 1;

		if (currentUser.getUserLevel() == 2) {
			return "businessListforDirector";
		} else {
			return "businessListforManager";
		}
	}

	// 查看服务详情
	public String viewBusinessDetail() {
		System.out.println("viewBusinessDetail:" + businessID);
		business = businessService.getBusiness(businessID);
		return "businessDetail";
	}

	// 进入创建服务
	public String viewCreateBusiness() {
		return "createBusiness";
	}

	// 保存创建的服务
	public String saveCreateBusiness() {
		System.out.println("saveCreateBusiness:" + business.getBusinessType()
				+ " " + business.getBusinessIntroduction() + " "
				+ business.getBusinessMemo());
		business.setBusinessCreateDate(new Date());
		business.setBusinessState(0);
		business.setUser(currentUser);

		boolean result = businessService.addBusiness(business);
		if (result == false)
			addActionMessage("<script>alert('创建失败！请检查输入是否完整');</script>");
		else
			addActionMessage("<script>alert('创建服务成功！');</script>");
		return "viewBusinessList";
	}

	// 进入编辑服务
	public String viewEditBusiness() {
		System.out.println("viewEditBusiness:" + businessID);
		business = businessService.getBusiness(businessID);
		return "editBusiness";
	}

	// 保存编辑的服务
	public String saveEditBusiness() {
		System.out.println("saveEditBusiness:" + business.getBusinessId()
				+ "\nType is :  " + business.getBusinessType());
		businessID = business.getBusinessId();
		Business one = businessService.getBusiness(business.getBusinessId());
		one.setBusinessIntroduction(business.getBusinessIntroduction());
		one.setBusinessMemo(business.getBusinessMemo());
		one.setBusinessType(business.getBusinessType());

		boolean result = businessService.updateBusiness(one);
		if (result == false)
			addActionMessage("<script>alert('保存失败！请检查输入是否完整');</script>");
		else
			addActionMessage("<script>alert('保存成功！');</script>");

		business = businessService.getBusiness(businessID);
		return "editBusiness";
	}

	// 停用服务
	public String dropBusiness() {
		System.out.println("dropBusiness:" + businessID);
		business = businessService.getBusiness(businessID);
		Boolean result = businessService.dropBusiness(business);
		if (result == true)
			addActionMessage("<script>alert('已停止该服务');</script>");
		else
			addActionMessage("<script>alert('停用失败，请重试');</script>");
		return "viewBusinessList";
	}

	// 进入服务分配
	public String viewDesignateBusiness() {
		System.out.println("viewDesignateBusiness:" + businessID);
		business = businessService.getBusiness(businessID);
		if (currentUser.getUserLevel() == 2)// 主管，可分配给所有客户
			customerlist = customerService.getNotLostCustomers();
		else
			customerlist = currentUser.getCustomers();
		return "designateBusiness";
	}

	// 保存分配
	public String saveDesignateBusiness() {
		System.out.println("saveDesignateBusiness: \nid:"
				+ business.getBusinessId() + "\n ID:" + businessID
				+ "\n  customer:" + customerID);
		businessID = business.getBusinessId();
		business = businessService.getBusiness(business.getBusinessId());
		business.setBusinessState(1);
		businessService.updateBusiness(business);

		Customer customer = customerService.getCustomer(customerID);
		BusinessDistribution businessDistribution = new BusinessDistribution(
				business, customer);
		boolean result = businessDistributionService
				.addBusinessDistribution(businessDistribution);
		if (result == false)
			addActionMessage("<script>alert('分配服务失败，请重试');</script>");
		else
			addActionMessage("<script>alert('分配成功！');</script>");
		System.out.println("businessID:" + businessID);// 有值
		// return "viewDesignateBusiness";// 未接受businessID

		// business = businessService.getBusiness(businessID);
		// if (currentUser.getUserLevel() == 2)// 主管，可分配给所有客户
		// customerlist = customerService.getNotLostCustomers();
		// else
		// customerlist = currentUser.getCustomers();
		// return "designateBusiness";

		return "viewBusinessList";
	}

	/* =======================服务分配排序======================= */
	// TODO Auto-generated method stub
	// 排序的服务分配列表
	public String sortBusinessDistributionList() {
		System.out.println("sortBusinessDistributionList-sortType:" + sortType
				+ " ,state:" + state);
		businessDistributionlist = businessDistributionService
				.getSortedBusinessDistributionList(sortType, currentUser, state);
		System.out
				.println("sortBusinessDistributionList--businessDistributionlist size:"
						+ businessDistributionlist.size());
		// 分页
		if (page > 0)
			;
		else
			page = 1;
		totalPage = (businessDistributionlist.size() - 1) / 10 + 1;
		businessDistributionlist = businessDistributionPageList(
				businessDistributionlist, page);
		isSort = 1;

		if (state == 1)
			return "businessProcessList";
		else if (state == 2)
			return "businessFeedbackList";
		return "businessFileList";
	}

	/* =======================服务处理======================= */
	// TODO Auto-generated method stub

	// 进入服务分配列表 主管可查看所有分配状态的服务分配，经理可查看自己建的分配状态的服务分配
	public String viewBusinessProcessList() {
		if (currentUser.getUserLevel() == 2) {
			businessDistributionlist = businessDistributionService
					.getDistributedBusinessDistributions();

		} else {
			businessDistributionlist = businessDistributionService
					.getManagerDistributedBusinessDistributions(currentUser);
		}
		// 分页
		if (page > 0)
			;
		else
			page = 1;
		isSort = 0;
		totalPage = (businessDistributionlist.size() - 1) / 10 + 1;
		businessDistributionlist = businessDistributionPageList(
				businessDistributionlist, page);
		return "businessProcessList";
	}

	// 查看待处理的服务分配详情
	public String viewDistributionDetail() {
		System.out.println("viewDistributionDetail: \nid:"
				+ businessDistribution.getBusinessDistributionId());
		businessDistribution = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		return "businessProcessDetail";
	}

	// 处理服务分配
	public String dealBusinessDistribution() {
		System.out.println("dealBusinessDistribution: \nid:"
				+ businessDistribution.getBusinessDistributionId() + "\nMemo:"
				+ businessDistribution.getBusinessDistributionMemo()
				+ "\n date:"
				+ businessDistribution.getBusinessDistributionDate());
		BusinessDistribution one = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		one.setBusinessDistributionMemo(businessDistribution
				.getBusinessDistributionMemo());
		one.setBusinessDistributionProcessDate(new Date());
		one.setBusinessDistributionState(2);
		boolean result = businessDistributionService
				.updateBusinessDistribution(one);
		if (result == true)
			addActionMessage("<script>alert('处理成功！');</script>");
		else
			addActionMessage("<script>alert('处理失败，请重试');</script>");
		return "viewBusinessProcessList";
	}

	// 停止该服务分配
	public String dropDistribution() {
		System.out.println("dropDistribution:  id:"
				+ businessDistribution.getBusinessDistributionId());
		businessDistribution = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		boolean result = businessDistributionService
				.dropBusinessDistribution(businessDistribution);
		if (result == true)
			addActionMessage("<script>alert('已停止该服务分配');</script>");
		else
			addActionMessage("<script>alert('停用失败，请重试');</script>");
		return "viewBusinessProcessList";
	}

	/* =======================服务反馈======================= */
	// TODO Auto-generated method stub
	// 进入服务反馈列表 主管可查看所有已处理的服务分配，经理可查看自己建的已处理的服务分配
	public String viewBusinessFeedBackList() {
		if (currentUser.getUserLevel() == 2) {
			businessDistributionlist = businessDistributionService
					.getDealedBusinessDistributions();
		} else {
			businessDistributionlist = businessDistributionService
					.getManagerDealedBusinessDistributions(currentUser);
		}
		// 分页
		if (page > 0)
			;
		else
			page = 1;
		isSort = 0;
		totalPage = (businessDistributionlist.size() - 1) / 10 + 1;
		businessDistributionlist = businessDistributionPageList(
				businessDistributionlist, page);
		return "businessFeedbackList";
	}

	// 查看待反馈的服务分配详情
	public String viewFeedBackDetail() {
		System.out.println("viewFeedBackDetail: \nid:"
				+ businessDistribution.getBusinessDistributionId());
		businessDistribution = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		return "businessFeedBackDetail";
	}

	// 反馈 服务分配
	public String feedBackBusinessDistribution() {
		int satisfiction = businessDistribution
				.getBusinessDisrtibutionSatisfaction();
		System.out.println("feedBackBusinessDistribution: \nid:"
				+ businessDistribution.getBusinessDistributionId()
				+ "\n satisfiction:" + satisfiction);

		BusinessDistribution one = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		one.setBusinessDisrtibutionSatisfaction(businessDistribution
				.getBusinessDisrtibutionSatisfaction());
		if (satisfiction > 3) {// 满意度大于3则归档
			one.setBusinessDistributionState(3);
		}
		boolean result = businessDistributionService
				.updateBusinessDistribution(one);
		if (result == true)
			addActionMessage("<script>alert('反馈成功！');</script>");
		else
			addActionMessage("<script>alert('反馈失败，请重试');</script>");

		return "viewBusinessFeedBackList";
	}

	/* =======================服务归档======================= */
	// TODO Auto-generated method stub

	// 进入服务归档列表 主管可查看所有已归档的服务分配，经理可查看自己建的已归档的服务分配
	public String viewBusinessFileList() {
		if (currentUser.getUserLevel() == 2) {
			businessDistributionlist = businessDistributionService
					.getFinishedBusinessDistributions();
		} else {
			businessDistributionlist = businessDistributionService
					.getManagerFinishedBusinessDistributions(currentUser);
		}
		// 分页
		if (page > 0)
			;
		else
			page = 1;
		isSort = 0;
		totalPage = (businessDistributionlist.size() - 1) / 10 + 1;
		businessDistributionlist = businessDistributionPageList(
				businessDistributionlist, page);
		return "businessFileList";
	}

	// 查看已归档的服务分配详情
	public String viewFileDetail() {
		System.out.println("viewFileDetail: \nid:"
				+ businessDistribution.getBusinessDistributionId());
		businessDistribution = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		return "businessFileDetail";
	}

	public BusinessDistribution getBusinessDistribution() {
		return businessDistribution;
	}

	public void setBusinessDistribution(
			BusinessDistribution businessDistribution) {
		this.businessDistribution = businessDistribution;
	}

	public Business getBusiness() {
		return business;
	}

	public void setBusiness(Business business) {
		this.business = business;
	}

	public List<Business> getBusinesslist() {
		return businesslist;
	}

	public void setBusinesslist(List<Business> businesslist) {
		this.businesslist = businesslist;
	}

	public String getBusinessID() {
		return businessID;
	}

	public void setBusinessID(String businessID) {
		this.businessID = businessID;
	}

	public User getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(User currentUser) {
		this.currentUser = currentUser;
	}

	public String getCustomerID() {
		return customerID;
	}

	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	public List<Customer> getCustomerlist() {
		return customerlist;
	}

	public void setCustomerlist(List<Customer> customerlist) {
		this.customerlist = customerlist;
	}

	public List<BusinessDistribution> getBusinessDistributionlist() {
		return businessDistributionlist;
	}

	public void setBusinessDistributionlist(
			List<BusinessDistribution> businessDistributionlist) {
		this.businessDistributionlist = businessDistributionlist;
	}

	public String getBusinessDistributionID() {
		return businessDistributionID;
	}

	public void setBusinessDistributionID(String businessDistributionID) {
		this.businessDistributionID = businessDistributionID;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getIsSort() {
		return isSort;
	}

	public void setIsSort(int isSort) {
		this.isSort = isSort;
	}
}
