package sunflower.business.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import sunflower.business.entity.Business;
import sunflower.business.entity.BusinessDistribution;
import sunflower.business.service.BusinessDistributionService;
import sunflower.business.service.BusinessService;
import sunflower.business.service.impl.BusinessDistributionServiceImpl;
import sunflower.business.service.impl.BusinessServiceImpl;
import sunflower.customer.entity.Customer;
import sunflower.customer.service.CustomerService;
import sunflower.customer.service.impl.CustomerServiceImpl;
import sunflower.user.entity.User;

import com.opensymphony.xwork2.ActionSupport;

public class BusinessAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	private BusinessService businessService;
	private BusinessDistributionService businessDistributionService;
	CustomerService customerService;
	private User currentUser;
	private String businessID;
	private String customerID;
	private String businessDistributionID;
	private Business business;// 销售机会
	private BusinessDistribution businessDistribution;
	private ArrayList<Business> businesslist;
	private ArrayList<BusinessDistribution> businessDistributionlist;
	private List<Customer> customerlist;

	private String sortType;// 排序方式
	private int state;// 服务分配状态

	public BusinessAction() {
		businessService = (BusinessService) ServletActionContext.getRequest()
				.getSession().getAttribute("businessService");
		if (businessService == null) {
			businessService = new BusinessServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("businessService", businessService);
		}

		businessDistributionService = (BusinessDistributionService) ServletActionContext
				.getRequest().getSession()
				.getAttribute("businessDistributionService");
		if (businessDistributionService == null) {
			businessDistributionService = new BusinessDistributionServiceImpl();
			ServletActionContext
					.getRequest()
					.getSession()
					.setAttribute("businessDistributionService",
							businessDistributionService);
		}

		customerService = (CustomerService) ServletActionContext.getRequest()
				.getSession().getAttribute("customerService");
		if (customerService == null) {
			customerService = new CustomerServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("customerService", customerService);
		}
		setCurrentUser((User) ServletActionContext.getRequest().getSession()
				.getAttribute("currentUser"));
	}

	/* =======================服务列表======================= */
	// TODO Auto-generated method stub

	// 进入服务列表
	// public String viewBusinessList() {
	// int page = 1; // 默认为当前是第一页
	// int record_per_page = 10; // 默认为每页显示10个记录
	// if (ServletActionContext.getRequest().getParameter("page") != null) {
	// page = Integer.parseInt(ServletActionContext.getRequest()
	// .getParameter("page"));
	// }
	// businesslist = (ArrayList<Business>) businessService.getBusinessByPage(
	// page, record_per_page);
	// System.out.println(businesslist.size());
	// return "businessList";
	// }

	// 进入服务列表
	public String viewBusinessList() {
		if (currentUser.getUserLevel() == 2) {
			businesslist = (ArrayList<Business>) businessService
					.getAllBusinesses();
			return "businessListforDirector";
		} else {
			businesslist = (ArrayList<Business>) businessService
					.getManagerBusinesses(currentUser);
			return "businessListforManager";
		}
	}

	// 排序的服务列表
	public String sortBusinessList() {
		System.out.println("sortBusinessList-sortType:" + sortType);
		businesslist = (ArrayList<Business>) businessService
				.getSortedBusinessList(sortType, currentUser);
		if (currentUser.getUserLevel() == 2) {
			return "businessListforDirector";
		} else {
			return "businessListforManager";
		}
	}

	// 查看服务详情
	public String viewBusinessDetail() {
		System.out.println("viewBusinessDetail:" + businessID);
		business = businessService.getBusiness(businessID);
		return "businessDetail";
	}

	// 进入创建服务
	public String viewCreateBusiness() {
		return "createBusiness";
	}

	// 保存创建的服务
	public String saveCreateBusiness() {
		System.out.println("saveCreateBusiness:" + business.getBusinessType()
				+ " " + business.getBusinessIntroduction() + " "
				+ business.getBusinessMemo());
		business.setBusinessCreateDate(new Date());
		business.setBusinessState(0);
		business.setUser(currentUser);

		boolean result = businessService.addBusiness(business);
		if (result == false)
			addActionMessage("<script>alert('创建失败！请检查输入是否完整');</script>");
		else
			addActionMessage("<script>alert('创建服务成功！');</script>");
		return "viewBusinessList";
	}

	// 进入编辑服务
	public String viewEditBusiness() {
		System.out.println("viewEditBusiness:" + businessID);
		business = businessService.getBusiness(businessID);
		return "editBusiness";
	}

	// 保存编辑的服务
	public String saveEditBusiness() {
		System.out.println("saveEditBusiness:" + business.getBusinessId()
				+ "\nType is :  " + business.getBusinessType());
		businessID = business.getBusinessId();
		Business one = businessService.getBusiness(business.getBusinessId());
		one.setBusinessIntroduction(business.getBusinessIntroduction());
		one.setBusinessMemo(business.getBusinessMemo());
		one.setBusinessType(business.getBusinessType());

		boolean result = businessService.updateBusiness(one);
		if (result == false)
			addActionMessage("<script>alert('保存失败！请检查输入是否完整');</script>");
		else
			addActionMessage("<script>alert('保存成功！');</script>");

		business = businessService.getBusiness(businessID);
		return "editBusiness";
	}

	// 停用服务
	public String dropBusiness() {
		System.out.println("dropBusiness:" + businessID);
		business = businessService.getBusiness(businessID);
		Boolean result = businessService.dropBusiness(business);
		if (result == true)
			addActionMessage("<script>alert('已停止该服务');</script>");
		else
			addActionMessage("<script>alert('停用失败，请重试');</script>");
		return "viewBusinessList";
	}

	// 进入服务分配
	public String viewDesignateBusiness() {
		System.out.println("viewDesignateBusiness:" + businessID);
		business = businessService.getBusiness(businessID);
		if (currentUser.getUserLevel() == 2)// 主管，可分配给所有客户
			customerlist = customerService.getNotLostCustomers();
		else
			customerlist = currentUser.getCustomers();
		return "designateBusiness";
	}

	// 保存分配
	public String saveDesignateBusiness() {
		System.out.println("saveDesignateBusiness: \nid:"
				+ business.getBusinessId() + "\n ID:" + businessID
				+ "\n  customer:" + customerID);
		businessID = business.getBusinessId();
		business = businessService.getBusiness(business.getBusinessId());
		business.setBusinessState(1);
		businessService.updateBusiness(business);

		Customer customer = customerService.getCustomer(customerID);
		BusinessDistribution businessDistribution = new BusinessDistribution(
				business, customer);
		boolean result = businessDistributionService
				.addBusinessDistribution(businessDistribution);
		if (result == false)
			addActionMessage("<script>alert('分配服务失败，请重试');</script>");
		else
			addActionMessage("<script>alert('分配成功！');</script>");
		System.out.println("businessID:" + businessID);// 有值
		// return "viewDesignateBusiness";// 未接受businessID

		business = businessService.getBusiness(businessID);
		if (currentUser.getUserLevel() == 2)// 主管，可分配给所有客户
			customerlist = customerService.getNotLostCustomers();
		else
			customerlist = currentUser.getCustomers();
		return "designateBusiness";
	}

	/* =======================服务分配排序======================= */
	// TODO Auto-generated method stub
	// 排序的服务分配列表
	public String sortBusinessDistributionList() {
		System.out.println("sortBusinessDistributionList-sortType:" + sortType
				+ " ,state:" + state);
		businessDistributionlist = (ArrayList<BusinessDistribution>) businessDistributionService
				.getSortedBusinessDistributionList(sortType, currentUser, state);
		if (state == 1)
			return "businessProcessList";
		else if (state == 2)
			return "businessFeedbackList";
		return "businessFileList";
	}

	/* =======================服务处理======================= */
	// TODO Auto-generated method stub

	// 进入服务分配列表 主管可查看所有分配状态的服务分配，经理可查看自己建的分配状态的服务分配
	public String viewBusinessProcessList() {
		if (currentUser.getUserLevel() == 2) {
			businessDistributionlist = (ArrayList<BusinessDistribution>) businessDistributionService
					.getDistributedBusinessDistributions();
		} else {
			businessDistributionlist = (ArrayList<BusinessDistribution>) businessDistributionService
					.getManagerDistributedBusinessDistributions(currentUser);
		}
		return "businessProcessList";
	}

	// 查看待处理的服务分配详情
	public String viewDistributionDetail() {
		System.out.println("viewDistributionDetail: \nid:"
				+ businessDistribution.getBusinessDistributionId());
		businessDistribution = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		return "businessProcessDetail";
	}

	// 处理服务分配
	public String dealBusinessDistribution() {
		System.out.println("dealBusinessDistribution: \nid:"
				+ businessDistribution.getBusinessDistributionId() + "\nMemo:"
				+ businessDistribution.getBusinessDistributionMemo()
				+ "\n date:"
				+ businessDistribution.getBusinessDistributionDate());
		BusinessDistribution one = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		one.setBusinessDistributionMemo(businessDistribution
				.getBusinessDistributionMemo());
		one.setBusinessDistributionProcessDate(new Date());
		one.setBusinessDistributionState(2);
		boolean result = businessDistributionService
				.updateBusinessDistribution(one);
		if (result == true)
			addActionMessage("<script>alert('处理成功！');</script>");
		else
			addActionMessage("<script>alert('处理失败，请重试');</script>");
		return "viewBusinessProcessList";
	}

	// 停止该服务分配
	public String dropDistribution() {
		System.out.println("dropDistribution:  id:"
				+ businessDistribution.getBusinessDistributionId());
		businessDistribution = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		boolean result = businessDistributionService
				.dropBusinessDistribution(businessDistribution);
		if (result == true)
			addActionMessage("<script>alert('已停止该服务分配');</script>");
		else
			addActionMessage("<script>alert('停用失败，请重试');</script>");
		return "viewBusinessProcessList";
	}

	/* =======================服务反馈======================= */
	// TODO Auto-generated method stub
	// 进入服务反馈列表 主管可查看所有已处理的服务分配，经理可查看自己建的已处理的服务分配
	public String viewBusinessFeedBackList() {
		if (currentUser.getUserLevel() == 2) {
			businessDistributionlist = (ArrayList<BusinessDistribution>) businessDistributionService
					.getDealedBusinessDistributions();
		} else {
			businessDistributionlist = (ArrayList<BusinessDistribution>) businessDistributionService
					.getManagerDealedBusinessDistributions(currentUser);
		}
		return "businessFeedbackList";
	}

	// 查看待反馈的服务分配详情
	public String viewFeedBackDetail() {
		System.out.println("viewFeedBackDetail: \nid:"
				+ businessDistribution.getBusinessDistributionId());
		businessDistribution = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		return "businessFeedBackDetail";
	}

	// 反馈 服务分配
	public String feedBackBusinessDistribution() {
		int satisfiction = businessDistribution
				.getBusinessDisrtibutionSatisfaction();
		System.out.println("feedBackBusinessDistribution: \nid:"
				+ businessDistribution.getBusinessDistributionId()
				+ "\n satisfiction:" + satisfiction);

		BusinessDistribution one = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		one.setBusinessDisrtibutionSatisfaction(businessDistribution
				.getBusinessDisrtibutionSatisfaction());
		if (satisfiction > 3) {// 满意度大于3则归档
			one.setBusinessDistributionState(3);
		}
		boolean result = businessDistributionService
				.updateBusinessDistribution(one);
		if (result == true)
			addActionMessage("<script>alert('反馈成功！');</script>");
		else
			addActionMessage("<script>alert('反馈失败，请重试');</script>");

		return "viewBusinessFeedBackList";
	}

	/* =======================服务归档======================= */
	// TODO Auto-generated method stub

	// 进入服务归档列表 主管可查看所有已归档的服务分配，经理可查看自己建的已归档的服务分配
	public String viewBusinessFileList() {
		if (currentUser.getUserLevel() == 2) {
			businessDistributionlist = (ArrayList<BusinessDistribution>) businessDistributionService
					.getFinishedBusinessDistributions();
		} else {
			businessDistributionlist = (ArrayList<BusinessDistribution>) businessDistributionService
					.getManagerFinishedBusinessDistributions(currentUser);
		}
		return "businessFileList";
	}

	// 查看已归档的服务分配详情
	public String viewFileDetail() {
		System.out.println("viewFileDetail: \nid:"
				+ businessDistribution.getBusinessDistributionId());
		businessDistribution = businessDistributionService
				.getBusinessDistribution(businessDistribution
						.getBusinessDistributionId());
		return "businessFileDetail";
	}

	public BusinessDistribution getBusinessDistribution() {
		return businessDistribution;
	}

	public void setBusinessDistribution(
			BusinessDistribution businessDistribution) {
		this.businessDistribution = businessDistribution;
	}

	public Business getBusiness() {
		return business;
	}

	public void setBusiness(Business business) {
		this.business = business;
	}

	public ArrayList<Business> getBusinesslist() {
		return businesslist;
	}

	public void setBusinesslist(ArrayList<Business> businesslist) {
		this.businesslist = businesslist;
	}

	public String getBusinessID() {
		return businessID;
	}

	public void setBusinessID(String businessID) {
		this.businessID = businessID;
	}

	public User getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(User currentUser) {
		this.currentUser = currentUser;
	}

	public String getCustomerID() {
		return customerID;
	}

	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	public List<Customer> getCustomerlist() {
		return customerlist;
	}

	public void setCustomerlist(List<Customer> customerlist) {
		this.customerlist = customerlist;
	}

	public ArrayList<BusinessDistribution> getBusinessDistributionlist() {
		return businessDistributionlist;
	}

	public void setBusinessDistributionlist(
			ArrayList<BusinessDistribution> businessDistributionlist) {
		this.businessDistributionlist = businessDistributionlist;
	}

	public String getBusinessDistributionID() {
		return businessDistributionID;
	}

	public void setBusinessDistributionID(String businessDistributionID) {
		this.businessDistributionID = businessDistributionID;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

}
