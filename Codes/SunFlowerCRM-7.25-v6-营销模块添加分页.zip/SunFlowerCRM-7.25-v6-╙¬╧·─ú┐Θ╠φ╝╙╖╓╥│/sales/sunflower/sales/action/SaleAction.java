package sunflower.sales.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import sunflower.sales.entity.Sale;
import sunflower.sales.service.SaleService;
import sunflower.sales.service.impl.SaleServiceImpl;
import sunflower.user.entity.User;
import sunflower.user.service.UserService;
import sunflower.user.service.impl.UserServiceImpl;

import com.opensymphony.xwork2.ActionSupport;

public class SaleAction extends ActionSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private SaleService saleService;
	private UserService userService;
	private User currentUser;
	private String managerID;
	private Sale sale;// 销售机会
	private List<Sale> saleslist;

	private ArrayList<User> managerlist;
	// private String[] checkbox;
	private String sortType;// 排序方式
	private int totalPage;
	private int page;
	private int isSort;// 排序与否的标志位， 默认否-0

	public SaleAction() {
		saleService = (SaleService) ServletActionContext.getRequest()
				.getSession().getAttribute("saleService");
		if (saleService == null) {
			saleService = new SaleServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("saleService", saleService);
		}
		userService = (UserService) ServletActionContext.getRequest()
				.getSession().getAttribute("userService");
		if (userService == null) {
			userService = new UserServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("userService", userService);
		}
		currentUser = (User) ServletActionContext.getRequest().getSession()
				.getAttribute("currentUser");
		isSort = 0;
	}

	// 分页 获取所有销售机会
	private List<Sale> salePageList() {
		page = 1;
		int start = (page - 1) * 10, end = page * 10;
		saleslist = saleService.getAvailSales(currentUser);

		if (saleslist.size() < end)
			end = saleslist.size();
		System.out.println("---page start:" + start + "  end:" + end);
		saleslist = saleslist.subList(start, end);// 包含起点不包含终点

		return saleslist;
	}

	// 返回列表时的分页 ，默认第一页
	private List<Sale> salePageList(List<Sale> saleslist, int page) {
		if (page > 0)
			;
		else
			page = 1;
		int start = (page - 1) * 10, end = page * 10;

		if (saleslist.size() < end)
			end = saleslist.size();
//		System.out.println("---page start:" + start + "  end:" + end);
		saleslist = saleslist.subList(start, end);// 包含起点不包含终点

		return saleslist;
	}

	// 排序 销售机会列表
	public String sortChancelist() {
		System.out.println("sortChancelist-sortType:" + sortType+"  sort:"+isSort);
		saleslist = saleService.getSortedSales(sortType, currentUser);
		// 分页
		if (page > 0)
			;
		else
			page = 1;
		totalPage = (saleslist.size() - 1) / 10 + 1;
		saleslist = salePageList(saleslist, page);
		isSort = 1;
		if (currentUser.getUserLevel() == 2) {
			return "chancelist";
		} else {
			return "designatedChanceList";
		}

	}

	// 进入销售机会列表
	public String viewChancelist() {
		// 判断是主管还是经理。主管进入销售机会管理页面，管理所有机会，可以创建机会。经理进入指派的销售机会列表页面。
		System.out.println("viewChancelist---page:" + page+"  sort:"+isSort);
		if (page > 0)
			;
		else
			page = 1;
		saleslist = saleService.getAvailSales(currentUser);
		// 分页
		totalPage = (saleslist.size() - 1) / 10 + 1;
		saleslist = salePageList(saleslist, page);
		isSort = 0;

		if (currentUser.getUserLevel() == 2) {
			return "chancelist";
		} else {
			return "designatedChanceList";
		}

	}

	// 主管 进入创建机会页面
	public String addChance() {
		return "createChance";
	}

	// 主管 创建机会保存
	public String saveChance() {
		sale.setUser1(currentUser);
		sale.setUser2(currentUser);// 数据库自动设为未指派
		sale.setSalesCreateTime(new Date());
		sale.setSalesState(0);
		boolean result = saleService.addSale(sale);
		if (result == false)
			addActionMessage("<script>alert('创建失败！请检查输入是否完整');</script>");
		else
			addActionMessage("<script>alert('创建成功！');</script>");

		// 分页
		saleslist = saleService.getAvailSales();
		totalPage = (saleslist.size() - 1) / 10 + 1;
		page = 1;
		saleslist = salePageList(saleslist, 1);
		isSort = 0;
		return "chancelist";
	}

	// 主管 删除机会
	public String delete() {
		System.out.println("sale-delete:" + sale.getSalesId());
		sale = saleService.getSale(sale.getSalesId());
		System.out.println("sale-delete:" + sale.getSalesCustomerName() + " "
				+ sale.getSalesBriefIntro());
		boolean result = saleService.dropSale(sale);
		System.out.println("sale-delete result:" + result);
		if (result == false)
			addActionMessage("<script>alert('删除失败，请重试');</script>");
		else
			addActionMessage("<script>alert('删除成功！');</script>");
		// return "viewChancelist";

		// 分页
		saleslist = saleService.getAvailSales();
		totalPage = (saleslist.size() - 1) / 10 + 1;
		page = 1;
		saleslist = salePageList(saleslist, 1);
		isSort = 0;
		return "chancelist";
	}

	// 主管 进入编辑机会页面
	public String viewEdit() {
		System.out.println("sale-edit:" + sale.getSalesId());
		sale = saleService.getSale(sale.getSalesId());
		return "editChance";
	}

	// 主管 编辑保存
	public String saveEdit() {
		Sale one = saleService.getSale(sale.getSalesId());
		one.setSalesCustomerName(sale.getSalesCustomerName());
		one.setSalesSource(sale.getSalesSource());
		one.setSalesBriefIntro(sale.getSalesBriefIntro());
		one.setSalesContactPerson(sale.getSalesContactPerson());
		one.setSalesContactTel(sale.getSalesContactTel());
		one.setSalesSuccessProb(sale.getSalesSuccessProb());
		one.setSalesDescription(sale.getSalesDescription());

		boolean result = saleService.updateSale(one);
		if (result == false) {
			addActionMessage("<script>alert('保存失败，请重试');</script>");
			return "editChance";
		} else {
			addActionMessage("<script>alert('保存成功！');</script>");
			// return "viewChancelist";
			// 分页
			saleslist = saleService.getAvailSales();
			totalPage = (saleslist.size() - 1) / 10 + 1;
			page = 1;
			saleslist = salePageList(saleslist, 1);
			isSort = 0;
			return "chancelist";
		}
	}

	// 主管 进入指派页面
	public String viewDesignate() {
		managerlist = (ArrayList<User>) userService.getManagers();
		sale = saleService.getSale(sale.getSalesId());
		return "designate";
	}

	// 主管 指派并保存
	public String saveDesignate() {
		System.out.println("sale-saveDesignate:" + managerID);

		sale = saleService.getSale(sale.getSalesId());
		User u = userService.getUser(managerID);
		u.addSales2(sale);// 需要保持数据一致性
		sale.setUser2(u);
		sale.setSalesState(1);// 已分配
		boolean result = saleService.updateSale(sale);
		System.out.println("saveDesignate result " + result);
		if (result == false) {
			addActionMessage("<script>alert('指派失败，请重试');</script>");
			return "viewDesignate";
		} else {
			addActionMessage("<script>alert('指派成功！');</script>");
			// 分页
			saleslist = saleService.getAvailSales();
			totalPage = (saleslist.size() - 1) / 10 + 1;
			page = 1;
			saleslist = salePageList(saleslist, 1);
			isSort = 0;
			return "chancelist";
		}
	}

	// 进入查看机会详情页面
	public String viewDetail() {
		System.out.println("sale-detail:" + sale.getSalesId());
		sale = saleService.getSale(sale.getSalesId());
		return "detailInfo";
	}

	public User getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(User currentUser) {
		this.currentUser = currentUser;
	}

	public Sale getSale() {
		return sale;
	}

	public void setSale(Sale sale) {
		this.sale = sale;
	}

	public String getManagerID() {
		return managerID;
	}

	public void setManagerID(String managerID) {
		this.managerID = managerID;
	}

	public ArrayList<User> getManagerlist() {
		return managerlist;
	}

	public void setManagerlist(ArrayList<User> managerlist) {
		this.managerlist = managerlist;
	}

	public String getSortType() {
		return sortType;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public List<Sale> getSaleslist() {
		return saleslist;
	}

	public void setSaleslist(List<Sale> saleslist) {
		this.saleslist = saleslist;
	}

	public int getIsSort() {
		return isSort;
	}

	public void setIsSort(int isSort) {
		this.isSort = isSort;
	}
}
