package sunflower.customer.action;
//Yangdi-2014-7-22
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import sunflower.customer.entity.Customer;
import sunflower.customer.entity.HistoryRecord;
import sunflower.customer.entity.PageBean;
import sunflower.customer.service.CustomerService;
import sunflower.customer.service.HistoryRecordService;
import sunflower.customer.service.impl.CustomerServiceImpl;
import sunflower.customer.service.impl.HistoryRecordServiceImpl;

import com.opensymphony.xwork2.ActionSupport;

public class HistoryRecordAction extends ActionSupport {
	
	/**
	 * 
	 */
	//for pagging
	private int page;
	private String sortFlag;	
	private String searchCusKey;
	
	private static final long serialVersionUID = 1L;
	private String customerId;
	private String customerName;
	private Customer customer;
	private List<HistoryRecord> historyRecords;
	HistoryRecordService historyRecordService;
    
	public HistoryRecordAction() {
		//System.out.println("CustomerAction:  CustomerAction()	-->	getin");
		historyRecordService = (HistoryRecordService) ServletActionContext.getRequest()
				.getSession().getAttribute("historyRecordService");
		if (historyRecordService == null) {
			historyRecordService = new HistoryRecordServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("historyRecordService", historyRecordService);
		}
	}
	
	public String getCustomerHistoryRecords2() throws UnsupportedEncodingException{
		customerName = new String(customerName.getBytes("ISO-8859-1"),"UTF8");

		String hql;
		hql = "from HistoryRecord where customer_id=?";
		
		PageBean pageBean = historyRecordService.getPageBean(6, page, hql, sortFlag, searchCusKey, customerId, customerName); 
		//将分页信息保存到Request
        HttpServletRequest request = ServletActionContext.getRequest();        
        request.setAttribute("pageBean", pageBean);
		
		//historyRecords = historyRecordService.getHistoryRecordByCustomerId(customerId);//.getCustomerHistoryRecords(customer);
		
		return "getCustomerHistoryRecords";
	} 
	
	public String getCustomerHistoryRecords() throws UnsupportedEncodingException{
		System.out.println("-->	进入 得到客户的历史订单");
		customerName = new String(customerName.getBytes("ISO-8859-1"),"UTF8");

		historyRecords = historyRecordService.getHistoryRecordByCustomerId(customerId);//.getCustomerHistoryRecords(customer);
		
		return "getCustomerHistoryRecords";
	} 
	

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public List<HistoryRecord> getHistoryRecords() {
		return historyRecords;
	}
	public void setHistoryRecords(List<HistoryRecord> historyRecords) {
		this.historyRecords = historyRecords;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public String getSortFlag() {
		return sortFlag;
	}

	public void setSortFlag(String sortFlag) {
		this.sortFlag = sortFlag;
	}

	public String getSearchCusKey() {
		return searchCusKey;
	}

	public void setSearchCusKey(String searchCusKey) {
		this.searchCusKey = searchCusKey;
	}
	
}
