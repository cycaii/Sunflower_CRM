document.writeln(" 欢迎 ");
document.writeln("              <a href=\"../user/personalinfo.html\"><strong>李黛娜</strong></a>");
document.writeln("				<span>|</span>");
document.writeln("                <a href=\"../../home.html\">主页</a>");
document.writeln("                <span>|</span>");
document.writeln("                设置");
document.writeln("                <span>|</span>");
document.writeln("              <a href=   \"../../login.html\">登出</a>");