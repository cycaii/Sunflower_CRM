package sunflower.customer.service;

import java.util.List;

import sunflower.customer.entity.Customer;
import sunflower.customer.entity.HistoryRecord;
import sunflower.customer.entity.PageBean;

public interface HistoryRecordService {
	public PageBean getPageBean(int pageSize, int page, String hql, String sortFlag, String searchCusKey, String customerId, String customerName);
	
	public List<HistoryRecord> getHistoryRecordByCustomerId(String customerId);
	
	public HistoryRecord getHistoryRecord(String historyRecordID);

	public List<HistoryRecord> getCustomerHistoryRecords(Customer customer);
}
