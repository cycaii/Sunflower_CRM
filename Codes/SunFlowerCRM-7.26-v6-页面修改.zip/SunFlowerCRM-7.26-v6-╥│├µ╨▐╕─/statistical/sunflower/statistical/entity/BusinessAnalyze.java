package sunflower.statistical.entity;

import java.io.Serializable;

public class BusinessAnalyze implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BusinessAnalyzeId id;
	public BusinessAnalyze()
	{
		
	}
	public BusinessAnalyzeId getId() {
		return id;
	}
	public void setId(BusinessAnalyzeId id) {
		this.id = id;
	}
}
