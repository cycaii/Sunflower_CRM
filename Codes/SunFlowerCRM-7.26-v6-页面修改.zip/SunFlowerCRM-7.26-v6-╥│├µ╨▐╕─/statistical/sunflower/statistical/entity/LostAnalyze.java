package sunflower.statistical.entity;

import java.io.Serializable;

public class LostAnalyze implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private LostAnalyzeId id;
	public LostAnalyze()
	{
	}
	public LostAnalyzeId getId() {
		return id;
	}
	public void setId(LostAnalyzeId id) {
		this.id = id;
	}
}
