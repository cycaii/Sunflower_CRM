package sunflower.statistical.entity;

import java.io.Serializable;

public class BusinessAnalyzeId implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String business_id;
	private String business_type;
	private int business_count;
	public String getBusiness_id() {
		return business_id;
	}
	public void setBusiness_id(String business_id) {
		this.business_id = business_id;
	}
	public String getBusiness_type() {
		return business_type;
	}
	public void setBusiness_type(String business_type) {
		this.business_type = business_type;
	}
	public int getBusiness_count() {
		return business_count;
	}
	public void setBusiness_count(int business_count) {
		this.business_count = business_count;
	}
}
