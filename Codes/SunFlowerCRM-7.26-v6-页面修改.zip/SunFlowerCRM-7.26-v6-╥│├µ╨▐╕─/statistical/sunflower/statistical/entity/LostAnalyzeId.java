package sunflower.statistical.entity;

import java.io.Serializable;

public class LostAnalyzeId implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String customer_lost_pause_id;
	private String user_name;
	private String user_id;
	private String customer_name;
	private String customer_lost_pause_reason;
	public String getCustomer_lost_pause_id() {
		return customer_lost_pause_id;
	}
	public void setCustomer_lost_pause_id(String customer_lost_pause_id) {
		this.customer_lost_pause_id = customer_lost_pause_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getCustomer_lost_pause_reason() {
		return customer_lost_pause_reason;
	}
	public void setCustomer_lost_pause_reason(String customer_lost_pause_reason) {
		this.customer_lost_pause_reason = customer_lost_pause_reason;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
}
