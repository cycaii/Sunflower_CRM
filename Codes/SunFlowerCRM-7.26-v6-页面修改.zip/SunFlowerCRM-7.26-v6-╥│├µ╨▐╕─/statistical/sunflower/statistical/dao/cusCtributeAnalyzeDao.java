package sunflower.statistical.dao;

import sunflower.util.support.HibernateUtil;

import org.hibernate.Session;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Restrictions;
import sunflower.customer.entity.*;

import java.util.ArrayList;
public class cusCtributeAnalyzeDao {
	private Session session;
	private Session session1;
	private Session session2;
	private Customer cus = new Customer();
	private Customer tcus = new Customer();
	public ArrayList<Customer> getAllCustomer(){
		session1 = HibernateUtil.getSessionFactory().getCurrentSession();
		session1.beginTransaction();
		ArrayList<Customer> customers = (ArrayList<Customer>)session1.createCriteria(Customer.class).add(Example.create(cus).excludeZeroes()).list();
		return customers;	
	}
	public Customer getCustomerByName(String customerName){
		session = HibernateUtil.getSessionFactory().getCurrentSession();
		session.beginTransaction();
		Customer customer = null;
		customer = (Customer)session.createCriteria(Customer.class).add(Restrictions.eq("customerName", customerName)).uniqueResult();
		return customer;
	}

}
