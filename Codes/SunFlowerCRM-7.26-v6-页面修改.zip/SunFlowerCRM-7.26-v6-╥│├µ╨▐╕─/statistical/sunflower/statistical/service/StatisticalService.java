package sunflower.statistical.service;

import java.util.List;

import sunflower.statistical.entity.BusinessAnalyze;
import sunflower.statistical.entity.ComponentAnalyze;
import sunflower.statistical.entity.LostAnalyze;

public interface StatisticalService {
	//lostAnalyze.jsp
	public List<LostAnalyze> getLostAnalyzeList();
	public List<LostAnalyze> getLostAnalyzeListByPage(int current_page, int record_per_page);
	public List<LostAnalyze> getLostAnalyzeListByPage_customerNameOrder(int current_page,int record_per_page);
	public List<LostAnalyze> getLostAnalyzeListByPage_userNameOrder(int current_page, int record_per_page);
	//businessAnalyze.jsp
	public List<BusinessAnalyze> getBusinessAnalyzeList();
	public List<BusinessAnalyze> getBusinessAnalyzeListByPage(int current_page, int record_per_page);
	public List<BusinessAnalyze> getBusinessAnalyzeListByPage_businessNumberOrder(int current_page,int record_per_page);
	public List<BusinessAnalyze> getBusinessAnalyzeListByPage_businessTypeOrder(int current_page,int record_per_page);
	//componentAnalyze.jsp
	//businessAnalyze.jsp
	public List<ComponentAnalyze> getComponentAnalyzeList();
	public List<ComponentAnalyze> getComponentAnalyzeListByPage(int current_page, int record_per_page);
	public List<ComponentAnalyze> getComponentAnalyzeListByPage_customerNumberOrder(int current_page,int record_per_page);
	public List<ComponentAnalyze> getComponentAnalyzeListByPage_customerLevelOrder(int current_page,int record_per_page);
}
