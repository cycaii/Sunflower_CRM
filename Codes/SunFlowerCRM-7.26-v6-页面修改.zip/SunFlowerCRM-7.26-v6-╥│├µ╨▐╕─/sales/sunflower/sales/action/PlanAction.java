package sunflower.sales.action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import sunflower.sales.entity.Plan;
import sunflower.sales.entity.Sale;
import sunflower.sales.entity.ScheduleItem;
import sunflower.sales.service.PlanService;
import sunflower.sales.service.SaleService;
import sunflower.sales.service.ScheduleItemService;
import sunflower.sales.service.impl.PlanServiceImpl;
import sunflower.sales.service.impl.SaleServiceImpl;
import sunflower.sales.service.impl.ScheduleItemServiceImpl;
import sunflower.user.entity.User;
import sunflower.user.service.UserService;
import sunflower.user.service.impl.UserServiceImpl;

import com.opensymphony.xwork2.ActionSupport;

public class PlanAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	private UserService userService;
	private SaleService saleService;
	private PlanService planService;
	private ScheduleItemService scheduleItemService;
	private User currentUser;
	private Sale sale;// 销售机会
	private Plan plan;
	private ScheduleItem scheduleItem;
	private ArrayList<Plan> planlist;
	private List<Sale> saleslist;
	private List<ScheduleItem> scheduleItemlist;
	private String sortType;// 排序方式
	private int totalPage;
	private int page;
	private int isSort;// 排序与否的标志位

	public PlanAction() {
		saleService = (SaleService) ServletActionContext.getRequest()
				.getSession().getAttribute("saleService");
		if (saleService == null) {
			saleService = new SaleServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("saleService", saleService);
		}

		planService = (PlanService) ServletActionContext.getRequest()
				.getSession().getAttribute("planService");
		if (planService == null) {
			planService = new PlanServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("planService", planService);
		}

		scheduleItemService = (ScheduleItemService) ServletActionContext
				.getRequest().getSession().getAttribute("scheduleItemService");
		if (scheduleItemService == null) {
			scheduleItemService = new ScheduleItemServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("scheduleItemService", scheduleItemService);
		}

		userService = (UserService) ServletActionContext.getRequest()
				.getSession().getAttribute("userService");
		if (userService == null) {
			userService = new UserServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("userService", userService);
		}
		currentUser = (User) ServletActionContext.getRequest().getSession()
				.getAttribute("currentUser");
		isSort = 0;
	}

	// 返回列表时的分页 ，默认第一页
	private List<Sale> salePageList(List<Sale> saleslist, int page) {
		if (page > 0)
			;
		else
			page = 1;
		int start = (page - 1) * 10, end = page * 10;

		if (saleslist.size() < end)
			end = saleslist.size();
		System.out.println("---page start:" + start + "  end:" + end);
		saleslist = saleslist.subList(start, end);// 包含起点不包含终点

		return saleslist;
	}

	// 排序 计划列表
	public String sortPlanlist() {
		System.out.println("sortPlanlist-sortType:" + sortType);
		saleslist = (ArrayList<Sale>) saleService.getSortedSalesforPlan(
				sortType, currentUser);
		System.out.println("sortPlanlist-saleslist size:" + saleslist.size());
		// 分页
		if (page > 0)
			;
		else
			page = 1;
		totalPage = (saleslist.size() - 1) / 10 + 1;
		saleslist = salePageList(saleslist, page);
		isSort = 1;

		if (currentUser.getUserLevel() == 2) {
			return "planListforDirector";
		} else {
			return "planListforManager";
		}

	}

	// 进入开发计划列表页面
	public String viewPlanlist() {
		// 主管
		if (currentUser.getUserLevel() == 2) {
			setSaleslist((ArrayList<Sale>) saleService.getAppointedSales());
			// 分页
			if (page > 0)
				;
			else
				page = 1;
			totalPage = (saleslist.size() - 1) / 10 + 1;
			saleslist = salePageList(saleslist, page);
			isSort = 0;
			return "planListforDirector";
		} else {// 经理
			setSaleslist((ArrayList<Sale>) saleService
					.getManagerAppointedSales(currentUser));
			// 分页
			if (page > 0)
				;
			else
				page = 1;
			totalPage = (saleslist.size() - 1) / 10 + 1;
			saleslist = salePageList(saleslist, page);
			isSort = 0;
			return "planListforManager";
		}

	}

	// 经理 进入创建页面
	public String viewCreate() {
		sale = saleService.getSale(sale.getSalesId());
		return "createPlan";
	}

	// 保存创建的计划
	public String saveCreate() {
		sale = saleService.getSale(sale.getSalesId());
		plan = new Plan(sale);
		planService.addPlan(plan);
		sale = saleService.getSale(sale.getSalesId());
		System.out.println("saveCreate: create plan:"
				+ sale.getPlans().get(0).getPlanId());
		scheduleItem.setPlan(sale.getPlans().get(0));
		boolean result = scheduleItemService.addScheduleItem(scheduleItem);

		if (result == false)
			addActionMessage("<script>alert('创建失败！请检查输入是否完整');</script>");
		else
			addActionMessage("<script>alert('创建成功！');</script>");

		return "viewPlanlist";
	}

	// 查看计划
	public String viewPlan() {
		sale = saleService.getSale(sale.getSalesId());
		scheduleItemlist = sale.getPlans().get(0).getScheduleItems();
		return "viewPlan";
	}

	// 前往编辑计划
	public String viewEdit() {
		sale = saleService.getSale(sale.getSalesId());
		scheduleItemlist = sale.getPlans().get(0).getScheduleItems();
		return "editPlan";
	}

	// 开始执行计划
	public String executePlan() {
		sale = saleService.getSale(sale.getSalesId());
		plan = sale.getPlans().get(0);
		plan.setPlanState(1);// 执行计划
		boolean result = planService.updatePlan(plan);

		if (result == false)
			addActionMessage("<script>alert('设置失败，请重试。');</script>");
		else
			addActionMessage("<script>alert('开始执行！');</script>");

		return "viewPlanlist";
	}

	// 前往计划执行反馈
	public String viewExecute() {
		sale = saleService.getSale(sale.getSalesId());
		scheduleItemlist = sale.getPlans().get(0).getScheduleItems();
		return "executePlan";
	}

	// 主管-前往审核计划
	public String viewAudit() {
		sale = saleService.getSale(sale.getSalesId());
		scheduleItemlist = sale.getPlans().get(0).getScheduleItems();
		return "auditPlan";
	}

	// 审核-完成计划
	public String finishPlan() {
		sale = saleService.getSale(sale.getSalesId());
		plan = sale.getPlans().get(0);
		plan.setPlanState(2);// 完成计划
		boolean result = planService.updatePlan(plan);

		if (result == false)
			addActionMessage("<script>alert('设置失败，请重试。');</script>");
		else
			addActionMessage("<script>alert('设置完成成功！');</script>");

		return "viewPlanlist";
	}

	// 审核-终止计划
	public String endPlan() {
		sale = saleService.getSale(sale.getSalesId());
		plan = sale.getPlans().get(0);
		plan.setPlanState(3);// 终止计划
		boolean result = planService.updatePlan(plan);

		if (result == false)
			addActionMessage("<script>alert('终止失败，请重试');</script>");
		else
			addActionMessage("<script>alert('终止计划成功！');</script>");
		return "viewPlanlist";
	}

	// 列表- 删除计划
	public String deletePlan() {
		sale = saleService.getSale(sale.getSalesId());
		plan = sale.getPlans().get(0);
		boolean result = planService.dropPlan(plan);

		if (result == false)
			addActionMessage("<script>alert('删除失败，请重试');</script>");
		else
			addActionMessage("<script>alert('删除成功，计划已终止');</script>");

		return "viewPlanlist";
	}

	// 编辑- 添加计划项
	public String addScheduleItem() {
		sale = saleService.getSale(sale.getSalesId());
		plan = sale.getPlans().get(0);
		scheduleItem.setPlan(plan);
		boolean result = scheduleItemService.addScheduleItem(scheduleItem);
		if (result == false)
			addActionMessage("<script>alert('添加计划项失败');</script>");
		else
			addActionMessage("<script>alert('已添加计划项 ');</script>");
		sale = saleService.getSale(sale.getSalesId());
		scheduleItemlist = sale.getPlans().get(0).getScheduleItems();
		return "editPlan";

		// return "viewEdit";
	}

	// 编辑-删除计划项
	public String deleteScheduleItem() {
		scheduleItem = scheduleItemService.getScheduleItem(scheduleItem
				.getScheduleId());
		sale = scheduleItem.getPlan().getSale();
		// plan = scheduleItem.getPlan();
		// plan.removeScheduleItem(scheduleItem);
		boolean result = scheduleItemService.deleteScheduleItem(scheduleItem);

		if (result == false)
			addActionMessage("<script>alert('删除计划项失败');</script>");
		else
			addActionMessage("<script>alert('已删除计划项 ');</script>");
		// sale = saleService.getSale(sale.getSalesId());
		scheduleItemlist = sale.getPlans().get(0).getScheduleItems();
		return "editPlan";
		// return "viewEdit";
	}

	// 更新计划项（添加执行效果）
	public String saveScheduleItem() {
		System.out.println("saveScheduleItem:  id:"
				+ scheduleItem.getScheduleId() + " memo: "
				+ scheduleItem.getScheduleMemo());
		ScheduleItem one = scheduleItemService.getScheduleItem(scheduleItem
				.getScheduleId());
		one.setScheduleMemo(scheduleItem.getScheduleMemo());
		boolean result = scheduleItemService.updateScheduleItem(one);

		if (result == false)
			addActionMessage("<script>alert('保存计划项失败');</script>");
		else
			addActionMessage("<script>alert('已保存计划项 ');</script>");

		sale = saleService.getSale(one.getPlan().getSale().getSalesId());
		scheduleItemlist = sale.getPlans().get(0).getScheduleItems();
		return "executePlan";
	}

	public User getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(User currentUser) {
		this.currentUser = currentUser;
	}

	public Sale getSale() {
		return sale;
	}

	public void setSale(Sale sale) {
		this.sale = sale;
	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	public ScheduleItem getScheduleItem() {
		return scheduleItem;
	}

	public void setScheduleItem(ScheduleItem scheduleItem) {
		this.scheduleItem = scheduleItem;
	}

	public ArrayList<Plan> getPlanlist() {
		return planlist;
	}

	public void setPlanlist(ArrayList<Plan> planlist) {
		this.planlist = planlist;
	}

	public List<ScheduleItem> getScheduleItemlist() {
		return scheduleItemlist;
	}

	public void setScheduleItemlist(List<ScheduleItem> scheduleItemlist) {
		this.scheduleItemlist = scheduleItemlist;
	}

	public List<Sale> getSaleslist() {
		return saleslist;
	}

	public void setSaleslist(List<Sale> saleslist) {
		this.saleslist = saleslist;
	}

	public String getSortType() {
		return sortType;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getIsSort() {
		return isSort;
	}

	public void setIsSort(int isSort) {
		this.isSort = isSort;
	}

	public void setSortType(String sortType) {
		this.sortType = sortType;
	}

}
