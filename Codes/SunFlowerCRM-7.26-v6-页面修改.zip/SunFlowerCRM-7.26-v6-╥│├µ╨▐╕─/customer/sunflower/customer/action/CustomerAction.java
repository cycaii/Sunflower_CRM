package sunflower.customer.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import sunflower.customer.entity.Customer;
import sunflower.customer.entity.CustomerLostPause;
import sunflower.customer.entity.CustomerType;
import sunflower.customer.entity.PageBean;
import sunflower.customer.service.CustomerLostPauseService;
import sunflower.customer.service.CustomerService;
import sunflower.customer.service.impl.CustomerLostPauseServiceImpl;
import sunflower.customer.service.impl.CustomerServiceImpl;
import sunflower.user.entity.User;
import sunflower.user.service.UserService;
import sunflower.user.service.impl.UserServiceImpl;

import com.opensymphony.xwork2.ActionSupport;

public class CustomerAction extends ActionSupport {
	
	List<Customer> list;
	
	CustomerService customerService;
	//PageBean pageBean;

	private int page;
	private String sortFlag;	
	private String searchCusKey;
	
	//for 预警
	private User currentUser;
	UserService userService;
	//for Apply Warn
	private String customerId;
	//for audit warn
	private String auditFlag;
	//for deal with warn
	private String dealWithFlag;
	private CustomerLostPause customerLostPause;
	//创建用户
	private Customer newCustomer;
	private List<User> userList;
	private String managerId;
	private List<CustomerType> typeList = new ArrayList<CustomerType>();
	private String typeId;
		
	public CustomerAction() {
		System.out.println("CustomerAction:  CustomerAction()	-->	getin");
		customerService = (CustomerService) ServletActionContext.getRequest()
				.getSession().getAttribute("customerService");
		if (customerService == null) {
			customerService = new CustomerServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("customerService", customerService);
		}		
		userService = (UserService) ServletActionContext.getRequest()
				.getSession().getAttribute("userService");
		if (userService == null) {
			userService = new UserServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("userService", userService);
		}
		//Login 时间已经放入
		currentUser = (User) ServletActionContext.getRequest().getSession()
				.getAttribute("currentUser");
		
	}
	
	//进入流失客户细节查看
	public String viewCustomer(){
		
		newCustomer = customerService.getCustomer(customerId);
		
		return "viewCustomer";
	}
	
	//保存新建客户
	public String saveNewCustomer(){
				
		boolean result = true;
		int level=0;
		
		newCustomer.setCustomerLevel(typeId);
		User user = userService.getUser(managerId);
		newCustomer.setUser(user);
		
		result = customerService.addCustomer(this.newCustomer);
		if(result==true)
		{
			addActionMessage("<script>alert('创建成功！');window.location.href='customer_getNotLostCustomers2.action';</script>");
		}else
		{
			addActionMessage("<script>alert('创建失败！');window.location.href='customer_getNotLostCustomers2.action';</script>");
		}
		
		return "saveNewCustomer";
	}

	//保存暂缓措施
	//Yangdi-2014-7-25-11:36pm
	public String saveDealWith(){
		
		boolean result = true;
		CustomerLostPauseService customerLostPauseService= new CustomerLostPauseServiceImpl();
		result = customerLostPauseService.saveCustomerLostPause(this.customerLostPause);
		
		if(result==true)
		{
			addActionMessage("<script>alert('暂缓成功成功！');</script>");
			return "saveDealWithSuccess";
		}
		else
		{
			addActionMessage("<script>alert('暂缓失败！');</script>");
			return "saveDealWithFail";
		}			
		
	}
	
	//进入暂缓页面
	//Yangdi-2014-7-25-9:54pm
	public String dealWithWarn(){
		
		if("dealWith".endsWith(dealWithFlag)){
			
			CustomerLostPauseService customerLostPauseService= new CustomerLostPauseServiceImpl();
			
			customerLostPause = customerLostPauseService.getCustomerLostPauseByCustomerId(customerId);
			
			return "dealWith";
		}
		else{
			
			Customer customer = customerService.getCustomer(customerId);
			customer.setCustomerState(4);
			boolean result = customerService.updateCustomer(customer);
			System.out.println("--> flag="+customer.getCustomerState());
			
			if(result==true)
				addActionMessage("<script>alert('审核成功！');</script>");
			else
				addActionMessage("<script>alert('审核失败！');</script>");
			
			return "lost";
		}

	}
	
	//进入暂缓客户列表
	//Yangdi-2014-7-25-9:14pm
	public String myLostCustomerList(){
		
		String hql = "from Customer where customer_state=3 and user_id='"+this.currentUser.getUserId()+"'";// and user_id="+this.currentUser.getUserId();
		PageBean pageBean = customerService.getPageBean(6, page, hql, sortFlag, searchCusKey);     
        HttpServletRequest request = ServletActionContext.getRequest();        
        request.setAttribute("pageBean", pageBean);
		
		return "myLostCustomerList";
	}
	
	//主管审核预警
	//Yangdi-2014-7-25-8:55pm
	public String auditWarn(){
		
		boolean result=true;
		int state;
		
		System.out.println("--> flag="+auditFlag);
		
		if("pass".endsWith(auditFlag))
		{
			CustomerLostPause customerLostPause = new CustomerLostPause();
			Customer customer = customerService.getCustomer(customerId);
			customer.addCustomerLostPaus(customerLostPause);
			customerLostPause.setCustomer(customer);
			CustomerLostPauseService customerLostPauseService = new CustomerLostPauseServiceImpl();
			customerLostPauseService.addCustomerLostPause(customerLostPause);
			state=3;
		}
		else
			state=0;
		
		Customer customer = customerService.getCustomer(customerId);
		customer.setCustomerState(state);
		result = customerService.updateCustomer(customer);
		System.out.println("--> flag="+customer.getCustomerState());
		
		if(result==true)
			addActionMessage("<script>alert('审核成功！');</script>");
		else
			addActionMessage("<script>alert('审核失败！');</script>");
		
		return "auditWarn";
	}

	//客户经理申请预警
	//Yangdi-2014-7-25-8:12pm
	public String applyWarn(){
		boolean result=true;
		Customer customer = customerService.getCustomer(customerId);
		customer.setCustomerState(1);
		result = customerService.updateCustomer(customer);
		
		if(result==true)
		{
			addActionMessage("<script>alert('申请成功！');");
		}else
		{
			addActionMessage("<script>alert('申请失败！');");
		}
		
		return "applyWarn";
	}

	//进入暂缓管理页面，判断权限进入不同页面
	//Yangdi-2014-7-25-6:00
	public String getNotLostCustomerForWarn(){
		
		String hql;
				
		if (currentUser.getUserLevel() == 2) {//客户主管
			hql = "from Customer where customer_state=1";
			PageBean pageBean = customerService.getPageBean(6, page, hql, sortFlag, searchCusKey);     
	        HttpServletRequest request = ServletActionContext.getRequest();        
	        request.setAttribute("pageBean", pageBean);
	        
			return "getCustomerListForCharger";
		} else {
			hql = "from Customer where customer_state<4 and user_id='"+this.currentUser.getUserId()+"'";
			PageBean pageBean = customerService.getPageBean(6, page, hql, sortFlag, searchCusKey);     
	        HttpServletRequest request = ServletActionContext.getRequest();        
	        request.setAttribute("pageBean", pageBean);
	        
			return "getCustomerListForManager";
		}
	}
	
	//获得流失客户列表
	//Yangdi-2014-7-24
	public String getLostCustomers(){

		String hql;
		hql = "from Customer where customer_state=4";
			
		//每一页显示6条数据
		PageBean pageBean = customerService.getPageBean(6, page, hql, sortFlag, searchCusKey);     
        HttpServletRequest request = ServletActionContext.getRequest();        
        request.setAttribute("pageBean", pageBean);
        		
		return "getLostCustomers";
	}
	
	//获得没有流失的客户列表
	//Yangdi-2014-7-21-带分页
	public String getNotLostCustomers2(){

		String hql;
		System.out.println("--> serachKey:"+searchCusKey);
		hql = "from Customer where customer_state<4 ";
			
		//每一页显示6条数据
		PageBean pageBean = customerService.getPageBean(6, page, hql, sortFlag, searchCusKey);     
        HttpServletRequest request = ServletActionContext.getRequest();        
        request.setAttribute("pageBean", pageBean);
        		
		return "getNotLostCustomers";
	}
	
	//废弃
	//Yangdi-2014-7-20-废弃方法
	public String getNotLostCustomers(){
		//Customer c = new Customer(); 
		//c.getHistoryRecords();
		System.out.println("CustomerAction:  getNotLostCustomers	-->	getin");
		list = this.customerService.getNotLostCustomers();
		System.out.println("CustomerAction:  getNotLostCustomers	-->	getout");
		if(list.size()==0)			
			System.out.println("CustomerAction:  getNotLostCustomers	-->	list.[0]:");
		return "getNotLostCustomers";
	}

	//进入客户创建页面
	//Yangdi-2014-7-22
	public String goToCreatePage(){
		
		userList = userService.getManagers();
		
		typeList.add(new CustomerType("0","战略伙伴客户"));
		typeList.add(new CustomerType("1","大客户"));	
		typeList.add(new CustomerType("2","普通客户"));
		
		newCustomer = new Customer();
		
		return "goToCreatePage";
	}
	
	//Yangdi-2014-7-22
	public String getsf(String sf){
		 String currentFlag = (sf == null)? "a": sf;
		 
		 return currentFlag;
	}
	
//================================================================================
//Getter & Setter
//================================================================================
	
	public List<Customer> getList() {
		return list;
	}

	public void setList(List<Customer> list) {
		this.list = list;
	}
	
	public String getSortFlag() {
		return sortFlag;
	}

	public void setSortFlag(String sortFlag) {
		this.sortFlag = sortFlag;
	}	
	
	public String getSearchCusKey() {
		return searchCusKey;
	}

	public void setSearchCusKey(String searchCusKey) {
		this.searchCusKey = searchCusKey;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}
	public CustomerService getCustomerService() {
		return customerService;
	}
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
	public User getCurrentUser() {
		return currentUser;
	}
	public void setCurrentUser(User currentUser) {
		this.currentUser = currentUser;
	}
	public UserService getUserService() {
		return userService;
	}
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAuditFlag() {
		return auditFlag;
	}

	public void setAuditFlag(String auditFlag) {
		this.auditFlag = auditFlag;
	}

	public String getDealWithFlag() {
		return dealWithFlag;
	}

	public void setDealWithFlag(String dealWithFlag) {
		this.dealWithFlag = dealWithFlag;
	}

	public CustomerLostPause getCustomerLostPause() {
		return customerLostPause;
	}

	public void setCustomerLostPause(CustomerLostPause customerLostPause) {
		this.customerLostPause = customerLostPause;
	}
	public Customer getNewCustomer() {
		return newCustomer;
	}
	public void setNewCustomer(Customer newCustomer) {
		this.newCustomer = newCustomer;
	}

	public List<User> getUserList() {
		return userList;
	}

	public void setUserList(List<User> userList) {
		this.userList = userList;
	}

	public String getManagerId() {
		return managerId;
	}

	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}

	public List<CustomerType> getTypeList() {
		return typeList;
	}

	public void setTypeList(List<CustomerType> typeList) {
		this.typeList = typeList;
	}

	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}
	
	
}
