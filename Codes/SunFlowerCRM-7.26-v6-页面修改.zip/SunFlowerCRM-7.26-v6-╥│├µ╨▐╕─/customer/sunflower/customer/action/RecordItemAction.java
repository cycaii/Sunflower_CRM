package sunflower.customer.action;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import sunflower.customer.entity.Customer;
import sunflower.customer.entity.HistoryRecord;
import sunflower.customer.entity.PageBean;
import sunflower.customer.entity.RecordItem;
import sunflower.customer.service.HistoryRecordService;
import sunflower.customer.service.RecordItemService;
import sunflower.customer.service.impl.HistoryRecordServiceImpl;
import sunflower.customer.service.impl.RecordItemServiceImpl;

import com.opensymphony.xwork2.ActionSupport;

public class RecordItemAction extends ActionSupport {
	
	//for pagging
	private int page;
	private String sortFlag;	
	private String searchCusKey;
	
	private String historyRecordId;

	private List<RecordItem> recordItemList;
	
	RecordItemService recordItemService;
	
	public RecordItemAction() {
		recordItemService = (RecordItemService) ServletActionContext.getRequest()
				.getSession().getAttribute("recordItemService");
		if (recordItemService == null) {
			recordItemService = new RecordItemServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("recordItemService", recordItemService);
		}
	}
	
	//得到历史订单里的订单条目
	public String getRecordItemList(){
		String hql;
		hql = "from RecordItem where history_record_id=?";
		
		PageBean pageBean = recordItemService.getPageBean(6, page, hql, sortFlag, searchCusKey, historyRecordId); 
        HttpServletRequest request = ServletActionContext.getRequest();        
        request.setAttribute("pageBean", pageBean);
		
		return "getRecordItemList";
	}

//============================================================================
//Getter & Setter
//============================================================================
	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public String getSortFlag() {
		return sortFlag;
	}

	public void setSortFlag(String sortFlag) {
		this.sortFlag = sortFlag;
	}

	public String getSearchCusKey() {
		return searchCusKey;
	}

	public void setSearchCusKey(String searchCusKey) {
		this.searchCusKey = searchCusKey;
	}

	public String getHistoryRecordId() {
		return historyRecordId;
	}

	public void setHistoryRecordId(String historyRecordId) {
		this.historyRecordId = historyRecordId;
	}

	public RecordItemService getRecordItemService() {
		return recordItemService;
	}

	public void setRecordItemService(RecordItemService recordItemService) {
		this.recordItemService = recordItemService;
	}

	public void setRecordItemList(List<RecordItem> recordItemList) {
		this.recordItemList = recordItemList;
	}
	

}
