package sunflower.customer.action;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import sunflower.customer.entity.ContactRecord;
import sunflower.customer.entity.Customer;
import sunflower.customer.entity.PageBean;
import sunflower.customer.service.ContactRecordService;
import sunflower.customer.service.CustomerService;
import sunflower.customer.service.impl.ContactRecordServiceImpl;
import sunflower.customer.service.impl.CustomerServiceImpl;

import com.opensymphony.xwork2.ActionSupport;

public class ContactRecordAction extends ActionSupport {
	
	//for pagging
	private int page;
	private String sortFlag;	
	private String searchCusKey;
	
	private static final long serialVersionUID = 1L;
	private String customerId;
	private String customerName;
	private Customer customer;
	private List<ContactRecord> contactRecords;
	
	//for edit contactRFecord
	private ContactRecord contactRecord;
	private String contactRecordId;
	
	ContactRecordService contactRecordService;
	
	//删除交往记录
	public String delete() throws UnsupportedEncodingException{
		
		//转码Action传来的值
		customerName = new String(customerName.getBytes("ISO-8859-1"),"UTF8");
		
		boolean result = contactRecordService.deleteContactRecordById(contactRecordId);
		if (result == false)
		{
			addActionMessage("<script>alert('删除失败！请重新尝试修改');</script>");
			
			return "deleteFail";
		}
		else
		{
			addActionMessage("<script>alert('删除成功！');"
					+ "window.location.href='contactRecord_getContactRecordList.action?customerId="+customerId+"&customerName="+customerName+"'</script>");

			return "deleteSuccess";
		}
	}
	
	//保存新建的交往记录
	public String saveAddContactRecord() throws UnsupportedEncodingException{
		customerName = new String(customerName.getBytes("ISO-8859-1"),"UTF8");
		
		CustomerService customerService = new CustomerServiceImpl();
		customer = customerService.getCustomer(customerId);
		
		contactRecord.setCustomer(customer);
		
		boolean result = contactRecordService.addContactRecord(contactRecord);
		if (result == false)
		{
			addActionMessage("<script>alert('添加失败！请重新尝试修改');</script>");
			
			return "saveEditFail";
		}
		else
		{			
			addActionMessage("<script>alert('添加成功！');"
					+ "window.location.href='contactRecord_getContactRecordList.action?customerId="+customerId+"&customerName="+customerName+"'</script>");
			return "saveEditSuccess";
		}
	}

	//进入添加交往记录页面
	public String addContactRecord(){
		contactRecord = new ContactRecord();
		return "addContactRecord";
	}
	
	//编辑交往记录
	//在contactlist.jsp中点编辑
	public String edit() throws UnsupportedEncodingException{	
		customerName = new String(customerName.getBytes("ISO-8859-1"),"UTF8");
		contactRecord = contactRecordService.getContactRecord(contactRecordId);
		
		return "edit";
	}
	
	//保存编辑后的结果
	//在editContacts.jsp中提交
	public String saveEdit(){
		
		boolean result = contactRecordService.saveEdit(contactRecord);
		
		System.out.println("--> 修改="+contactRecord.getContactRecordId());
		
		if (result == false)
		{
			addActionMessage("<script>alert('修改失败！请重新尝试修改');</script>");
			
			return "saveEditFail";
		}
		else
		{			
			addActionMessage("<script>alert('修改成功！');"
					+ "window.location.href='contactRecord_getContactRecordList.action?customerId="+customerId+"&customerName="+customerName+"'</script>");
			//System.out.println("--> 修改="+customerId);
			return "saveEditSuccess";
		}
	}
	
	public ContactRecordAction() {
		contactRecordService = (ContactRecordService) ServletActionContext.getRequest()
				.getSession().getAttribute("contactRecordService");
		if (contactRecordService == null) {
			contactRecordService = new ContactRecordServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("contactRecordService", contactRecordService);
		}
	}
	
	public String getContactRecordList() throws UnsupportedEncodingException{
		
		customerName = new String(customerName.getBytes("ISO-8859-1"),"UTF8");

		String hql;
		hql = "from ContactRecord where customer_id=?";
		
		PageBean pageBean = contactRecordService.getPageBean(6, page, hql, sortFlag, searchCusKey, customerId, customerName); 
        HttpServletRequest request = ServletActionContext.getRequest();        
        request.setAttribute("pageBean", pageBean);		
		
		return "getContactRecordList";
	}
	
//==================================================================================
//Getter & Setter
//==================================================================================
	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public String getSortFlag() {
		return sortFlag;
	}

	public void setSortFlag(String sortFlag) {
		this.sortFlag = sortFlag;
	}

	public String getSearchCusKey() {
		return searchCusKey;
	}

	public void setSearchCusKey(String searchCusKey) {
		this.searchCusKey = searchCusKey;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<ContactRecord> getContactRecords() {
		return contactRecords;
	}

	public void setContactRecords(List<ContactRecord> contactRecords) {
		this.contactRecords = contactRecords;
	}

	public ContactRecordService getContactRecordService() {
		return contactRecordService;
	}

	public void setContactRecordService(ContactRecordService contactRecordService) {
		this.contactRecordService = contactRecordService;
	}

	public ContactRecord getContactRecord() {
		return contactRecord;
	}

	public void setContactRecord(ContactRecord contactRecord) {
		this.contactRecord = contactRecord;
	}

	public String getContactRecordId() {
		return contactRecordId;
	}

	public void setContactRecordId(String contactRecordId) {
		this.contactRecordId = contactRecordId;
	}
	
	

}
