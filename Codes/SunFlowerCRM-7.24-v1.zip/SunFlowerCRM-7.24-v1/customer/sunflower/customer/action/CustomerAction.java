package sunflower.customer.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import sunflower.customer.entity.Customer;
import sunflower.customer.entity.PageBean;
import sunflower.customer.service.CustomerService;
import sunflower.customer.service.impl.CustomerServiceImpl;
import sunflower.user.service.UserService;
import sunflower.user.service.impl.UserServiceImpl;

import com.opensymphony.xwork2.ActionSupport;

public class CustomerAction extends ActionSupport {
	
	List<Customer> list;
	
	CustomerService customerService;
	//PageBean pageBean;

	private int page;
	private String sortFlag;	
	private String searchCusKey;
	
	//Yangdi-2014-7-22
	public String goToCreatePage(){
		return "goToCreatePage";
	}
	
	//Yangdi-2014-7-22
	public String getsf(String sf){
		 String currentFlag = (sf == null)? "a": sf;
		 
		 return currentFlag;
	}
	
	public String getSortFlag() {
		return sortFlag;
	}

	public void setSortFlag(String sortFlag) {
		this.sortFlag = sortFlag;
	}	
	
	public String getSearchCusKey() {
		return searchCusKey;
	}

	public void setSearchCusKey(String searchCusKey) {
		this.searchCusKey = searchCusKey;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public CustomerAction() {
		System.out.println("CustomerAction:  CustomerAction()	-->	getin");
		customerService = (CustomerService) ServletActionContext.getRequest()
				.getSession().getAttribute("customerService");
		if (customerService == null) {
			customerService = new CustomerServiceImpl();
			ServletActionContext.getRequest().getSession()
					.setAttribute("customerService", customerService);
		}
	}
	
	//Yangdi-2014-7-21-带分页
	public String getNotLostCustomers2(){

		String hql;
		System.out.println("--> serachKey:"+searchCusKey);
		//hql = "from Customer as c, User as u where c.user_id=u.user_id and customer_state<4 ";
		hql = "from Customer where customer_state<4 ";
			
		//每一页显示6条数据
		PageBean pageBean = customerService.getPageBean(6, page, hql, sortFlag, searchCusKey);     
		//将分页信息保存到Request
        HttpServletRequest request = ServletActionContext.getRequest();        
        request.setAttribute("pageBean", pageBean);
        		
		return "getNotLostCustomers";
	}
	
	//Yangdi-2014-7-20-废弃方法
	public String getNotLostCustomers(){
		//Customer c = new Customer(); 
		//c.getHistoryRecords();
		System.out.println("CustomerAction:  getNotLostCustomers	-->	getin");
		list = this.customerService.getNotLostCustomers();
		System.out.println("CustomerAction:  getNotLostCustomers	-->	getout");
		if(list.size()==0)			
			System.out.println("CustomerAction:  getNotLostCustomers	-->	list.[0]:");
		return "getNotLostCustomers";
	}

	public List<Customer> getList() {
		return list;
	}

	public void setList(List<Customer> list) {
		this.list = list;
	}
	
	
}
